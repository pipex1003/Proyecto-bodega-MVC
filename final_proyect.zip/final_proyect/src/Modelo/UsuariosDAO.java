package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import java.sql.SQLException;

public class UsuariosDAO {
   Conexion cn = new Conexion();
   Connection con;
   PreparedStatement ps;
   ResultSet rs;

   public Usuarios Login(String usuario, String clave) {
       Usuarios us = new Usuarios();
       String sqlEmpleados = "SELECT * FROM empleados WHERE usuario = ? AND clave = ? ";

       try {
           con = cn.getConexion();
           ps = con.prepareStatement(sqlEmpleados);
           ps.setObject(1, usuario);
           ps.setObject(2, clave);
           rs = ps.executeQuery();

           if (rs.next()) {
               us.setId(rs.getInt("empleadoID"));
               us.setUsuario(rs.getString("usuario"));
               us.setNombre(rs.getString("nombre"));
               us.setClave(rs.getString("clave"));
               us.setRol(rs.getString("rol"));
               us.setEstado(rs.getString("estado"));
//               System.out.println(us.getEstado());
//               if ("inactivo".equals(us.getEstado())) {
//                  return null;
//               }

               return us;
           }
       } catch (SQLException e) {
           JOptionPane.showMessageDialog(null, e.toString());
       } finally {
           // Cerrar recursos (rs, ps, con) aquí
       }
       return null;
   }
}
