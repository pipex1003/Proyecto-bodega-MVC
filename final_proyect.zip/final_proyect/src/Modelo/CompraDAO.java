/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ANDRES AVILA
 */
public class CompraDAO {
   
    private Connection conexion;

    public CompraDAO() {
        Conexion conectaBD = new Conexion();
        conexion = conectaBD.getConexion();
    }

   public void ingresarCompra(Compra compra) {
   try {
       String sql = "INSERT INTO compra (Numero_de_factura, cantidad, Valor_de_compra, impuesto, total_pagar,Fecha_de_compra, Serializado, proveedorID) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
       PreparedStatement statement = conexion.prepareStatement(sql);
       statement.setInt(1, compra.getNumeroDeFactura());
       statement.setInt(2, compra.getCantidad());
       statement.setDouble(3, compra.getValorDeCompra());
       statement.setDouble(4, compra.getImpuesto());
       statement.setDouble(5, compra.getTotalPagar());
       statement.setString (6,  compra.getFechaDeCompra());
       statement.setInt(7, compra.getSerializado());
       statement.setInt(8, compra.getProveedorID());

       int rowsInserted = statement.executeUpdate();
       if (rowsInserted > 0) {
           System.out.println("Nueva compra agregada correctamente!");
       }
   } catch (SQLException ex) {
       ex.printStackTrace();
   }
}


    public void modificarCompra(Compra compra) {
   try {
       String sql = "UPDATE compra SET cantidad=?, Valor_de_compra=?, impuesto=?, total_pagar=?, Fecha_de_compra=?, Serializado=?, proveedorID=? WHERE Numero_de_factura=?";
       PreparedStatement statement = conexion.prepareStatement(sql);
       statement.setInt(1, compra.getCantidad());
       statement.setDouble(2, compra.getValorDeCompra());
       statement.setDouble(3, compra.getImpuesto());
       statement.setDouble(4, compra.getTotalPagar());
       statement.setString (5, compra.getFechaDeCompra());
       statement.setInt(6, compra.getSerializado());
       statement.setInt(7, compra.getProveedorID());
       statement.setInt(8, compra.getNumeroDeFactura());

       int rowsUpdated = statement.executeUpdate();
       if (rowsUpdated > 0) {
           System.out.println("Compra modificada correctamente!");
       }
   } catch (SQLException ex) {
       ex.printStackTrace();
   }
}

public void borrarCompra(int numeroDeFactura) {
   try {
       String sql = "DELETE FROM compra WHERE Numero_de_factura=?";
       PreparedStatement statement = conexion.prepareStatement(sql);
       statement.setInt(1, numeroDeFactura);

       int rowsDeleted = statement.executeUpdate();
       if (rowsDeleted > 0) {
           System.out.println("Compra eliminado correctamente!");
       }
   } catch (SQLException ex) {
       ex.printStackTrace();
   }
}
public void llenarTablaCompras(JTable tablaCompras) {
   try {
       String sql = "SELECT * FROM compra";
       PreparedStatement statement = conexion.prepareStatement(sql);

       ResultSet resultado = statement.executeQuery();

       DefaultTableModel modelo = new DefaultTableModel();
       tablaCompras.setModel(modelo);

       modelo.addColumn("Numero_de_factura");
       modelo.addColumn("cantidad");
       modelo.addColumn("Valor_de_compra");
       modelo.addColumn("impuesto");
       modelo.addColumn("total_pagar");
       modelo.addColumn("Fecha_de_compra");
       modelo.addColumn("Serializado");
       modelo.addColumn("proveedorID");

       while (resultado.next()) {
           Object[] fila = new Object[8];
           for (int i = 0; i < 8; i++) {
               fila[i] = resultado.getObject(i + 1);
           }
           modelo.addRow(fila);
       }

   } catch (SQLException ex) {
       ex.printStackTrace();
   }
}

    public String buscarCompra(int numeroDeFactura) {
        String query = "SELECT Numero_de_factura, cantidad, Valor_de_compra, impuesto, total_pagar, Fecha_de_compra, Serializado, proveedorID FROM compra WHERE Numero_de_factura = ?";
        StringBuilder resultado = new StringBuilder();

        try (PreparedStatement statement = conexion.prepareStatement(query)) {
            statement.setInt(1, numeroDeFactura);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    int factura = resultSet.getInt("Numero_de_factura");
                    int cantidad = resultSet.getInt("cantidad");
                    double valorCompra = resultSet.getDouble("Valor_de_compra");
                    double impuesto = resultSet.getDouble("impuesto");
                    double totalPagar = resultSet.getDouble("total_pagar");
                    String fechaCompra = resultSet.getString("Fecha_de_compra");
                    int serializado = resultSet.getInt("Serializado");
                    int proveedorID = resultSet.getInt("proveedorID");

                    resultado.append(factura).append(", ");
                    resultado.append(cantidad).append(", ");
                    resultado.append(valorCompra).append(", ");
                    resultado.append(impuesto).append(", ");
                    resultado.append(totalPagar).append(", ");
                    resultado.append(fechaCompra).append(", ");
                    resultado.append(serializado).append(", ");
                    resultado.append(proveedorID).append(", ");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (resultado.length() > 0) {
            resultado.delete(resultado.length() - 2, resultado.length());
        }

        return resultado.toString();
    }



}

