/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author ANDRES AVILA
 */
public class EmpleadoCentro {
 


  private int EmpleadoID;
  private int CentroDeCostoID;

  public EmpleadoCentro() {
  }

  public EmpleadoCentro(int EmpleadoID, int CentroDeCostoID) {
      this.EmpleadoID = EmpleadoID;
      this.CentroDeCostoID = CentroDeCostoID;
  }

  public int getEmpleadoID() {
      return EmpleadoID;
  }

  public void setEmpleadoID(int EmpleadoID) {
      this.EmpleadoID = EmpleadoID;
  }

  public int getCentroDeCostoID() {
      return CentroDeCostoID;
  }

  public void setCentroDeCostoID(int CentroDeCostoID) {
      this.CentroDeCostoID = CentroDeCostoID;
  }
}


