
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.Component;
import javax.swing.JOptionPane;
import Modelo.Usuarios;
import Vista.FormularioEmpleados;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
public class EmpleadoDAO {
    private Connection conexion;

    public EmpleadoDAO() {
        Conexion conectar = new Conexion();
        conexion = conectar.getConexion();
    }

    public void llenarTablaEmpleados(JTable tabla) {
        String query = "SELECT empleadoID, nombre, correo, identificacion, Fecha_nacimiento, telefono, fechaIngreso, salario, estado,rol FROM empleados";
        try (PreparedStatement statement = conexion.prepareStatement(query); ResultSet resultSet = statement.executeQuery()) {
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("ID");
            model.addColumn("Nombre");
            model.addColumn("Correo");
            model.addColumn("Identificación");
            model.addColumn("Fecha Nacimiento");
            model.addColumn("Teléfono");
            model.addColumn("Fecha Ingreso");
            model.addColumn("Salario");
            model.addColumn("Estado");
            model.addColumn("Rol");
            while (resultSet.next()) {
                int empleadoID = resultSet.getInt("empleadoID");
                String nombre = resultSet.getString("nombre");
                String correo = resultSet.getString("correo");
                int identificacion = resultSet.getInt("identificacion");
                String fechaNacimiento = resultSet.getString("Fecha_nacimiento");
                int telefono = resultSet.getInt("telefono");
                String fechaIngreso = resultSet.getString("fechaIngreso");
                double salario = resultSet.getDouble("salario");
                String estado = resultSet.getString("estado");
                String rol = resultSet.getString("rol");
                model.addRow(new Object[]{empleadoID, nombre, correo, identificacion, fechaNacimiento, telefono, fechaIngreso, salario, estado,rol});
            }
            tabla.setModel(model);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

  public void agregarEmpleado(Empleado empleado) {
    String query = "INSERT INTO empleados (EmpleadoID, Nombre, Correo, Identificacion, Fecha_nacimiento, Telefono, FechaIngreso, Salario, Estado, Usuario, Clave, Rol) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    try (PreparedStatement statement = conexion.prepareStatement(query)) {
        statement.setInt(1, empleado.getEmpleadoID());
        statement.setString(2, empleado.getNombre());
        statement.setString(3, empleado.getCorreo());
        statement.setInt(4, empleado.getIdentificacion());
        statement.setString(5, empleado.getFechaNacimiento());
        statement.setInt(6, empleado.getTelefono());
        statement.setString(7, empleado.getFechaIngreso());
        statement.setDouble(8, empleado.getSalario());
        statement.setString(9, empleado.getEstado());
        statement.setString(10, empleado.getUsuario());
        statement.setString(11, empleado.getClave());
        statement.setString(12, empleado.getRol());

        statement.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
    public void deshabilitarE(int empleadoID) {
        String query = "UPDATE empleados SET Estado = 'inactivo' WHERE EmpleadoID = ?";
        try (PreparedStatement statement = conexion.prepareStatement(query)) {
            statement.setInt(1, empleadoID);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
      public void habilitarE(int empleadoID) {
        String query = "UPDATE empleados SET Estado = 'activo' WHERE EmpleadoID = ?";
        try (PreparedStatement statement = conexion.prepareStatement(query)) {
            statement.setInt(1, empleadoID);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Resto de los métodos...
     public String buscarEmpleado(int empleadoID) {
        String query = "SELECT empleadoID, nombre, correo, identificacion, Fecha_nacimiento, telefono, fechaIngreso, salario, estado FROM empleados WHERE empleadoID = ?";
        StringBuilder resultado = new StringBuilder();

        try (PreparedStatement statement = conexion.prepareStatement(query)) {
            statement.setInt(1, empleadoID);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    int empleadoIDbd = resultSet.getInt("empleadoID");
                    String nombre = resultSet.getString("nombre");
                    String correo = resultSet.getString("correo");
                    int identificacion = resultSet.getInt("identificacion");
                    String fechaNacimiento = resultSet.getString("Fecha_nacimiento");
                    int telefono = resultSet.getInt("telefono");
                    String fechaIngreso = resultSet.getString("fechaIngreso");
                    double salario = resultSet.getDouble("salario");
                    String estado = resultSet.getString("estado");
                    resultado.append(empleadoIDbd).append(", ");
                    resultado.append(nombre).append(", ");
                    resultado.append(correo).append(", ");
                    resultado.append(identificacion).append(", ");
                    resultado.append(fechaNacimiento).append(", ");
                    resultado.append(telefono).append(", ");
                    resultado.append(fechaIngreso).append(", ");
                    resultado.append(salario).append(", ");
                    resultado.append(estado).append(", ");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (resultado.length() > 0) {
            resultado.delete(resultado.length() - 2, resultado.length());
        }

        return resultado.toString();
    }

 public void editarEmpleado(Empleado empleado) {
    // Comprobamos si el usuario que está intentando actualizar los datos es administrador.
    UsuariosDAO usuariosDAO = new UsuariosDAO();
    Usuarios usuarioActual = usuariosDAO.Login(Usuarios.getUsuario(), Usuarios.getClave());

//    // Si el usuario no es administrador, solo actualizamos los campos que no sean la identificación
//    if (!usuarioActual.getRol().equals("administrador")) {
//        String query = "UPDATE empleados SET Nombre = ?, Correo = ?, Fecha_nacimiento = ?, Telefono = ?, FechaIngreso = ?, Salario = ?, Usuario = ?, Clave = ? WHERE EmpleadoID = ?";
//        try (PreparedStatement statement = conexion.prepareStatement(query)) {
//            statement.setString(1, empleado.getNombre());
//            statement.setString(2, empleado.getCorreo());
//            statement.setString(3, empleado.getFechaNacimiento());
//            statement.setInt(4, empleado.getTelefono());
//            statement.setString(5, empleado.getFechaIngreso());
//            statement.setDouble(6, empleado.getSalario());
//            statement.setString(9, empleado.getUsuario());
//            statement.setString(10,empleado.getClave());
//            statement.setInt(9, empleado.getEmpleadoID());
//            statement.executeUpdate();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    } else {
        // Si el usuario es administrador, actualizamos todos los campos
        String query = "UPDATE empleados SET Nombre = ?, Correo = ?, Identificacion = ?, Fecha_nacimiento = ?, Telefono = ?, FechaIngreso = ?, Salario = ?, Usuario = ?, Clave = ? ,rol= ?WHERE EmpleadoID = ?";
        try (PreparedStatement statement = conexion.prepareStatement(query)) {
            statement.setString(1, empleado.getNombre());
            statement.setString(2, empleado.getCorreo());
            statement.setInt(3, empleado.getIdentificacion());
            statement.setString(4, empleado.getFechaNacimiento());
            statement.setInt(5, empleado.getTelefono());
            statement.setString(6, empleado.getFechaIngreso());
            statement.setDouble(7, empleado.getSalario());
            statement.setString(8, empleado.getUsuario());
            statement.setString(9,empleado.getClave());
            statement.setInt(10, empleado.getEmpleadoID());
            statement.setString(11,empleado.getRol());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
//}

       public void eliminarEmpleado(int empleadoID) {
        String query = "DELETE FROM empleados WHERE EmpleadoID = ?";

        try (PreparedStatement statement = conexion.prepareStatement(query)) {
            statement.setInt(1, empleadoID);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public double calcularBonoCumpleaños(int empleadoID) {
        try {
            // Consultar la fecha de cumpleaños del empleado con el ID dado
            String query = "SELECT Fecha_nacimiento, Salario FROM empleados WHERE EmpleadoID = ?";
            try (PreparedStatement statement = conexion.prepareStatement(query)) {
                statement.setInt(1, empleadoID);

                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        // Obtener la fecha de cumpleaños y salario del resultado
                        String fechaCumpleañosStr = resultSet.getString("Fecha_nacimiento");
                        double salarioActual = resultSet.getDouble("Salario");

                        // Convertir la fecha de cumpleaños a LocalDate
                        LocalDate fechaCumpleaños = LocalDate.parse(fechaCumpleañosStr);

                        // Obtener la fecha actual
                        LocalDate fechaActual = LocalDate.now();

                        // Verificar si la fecha de cumpleaños coincide con la fecha actual
                        if (fechaCumpleaños.getMonth() == fechaActual.getMonth() && fechaCumpleaños.getDayOfMonth() == fechaActual.getDayOfMonth()) {
                            // Calcular el bono del 10% sobre el salario del empleado
                            double bono = salarioActual * 0.10;

                            // Realizar la acción correspondiente, como mostrar un mensaje
                            //System.out.println("¡Feliz cumpleaños! Has ganado un bono del 10% sobre tu salario. Bono: $" + bono);

                            // Retornar el valor del bono
                            return bono;
                        }
                    }
                }
            }
        } catch (SQLException | DateTimeParseException e) {
            e.printStackTrace(); // Maneja las excepciones adecuadamente
        }

        // Si no se cumple la condición, retornar 0 indicando que no hay bono
        return 0.0;
    }
    public String obtenerEstadoEmpleado(int empleadoID) {
    String estado = "";
    try {
        String query = "SELECT Estado FROM Empleados WHERE EmpleadoID = ?";
        PreparedStatement statement = conexion.prepareStatement(query);
        statement.setInt(1, empleadoID);

        ResultSet resultSet = statement.executeQuery();

        while (resultSet.next()) {
            estado = resultSet.getString("Estado");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return estado;
}
}
