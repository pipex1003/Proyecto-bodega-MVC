/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;


import java.util.Date;


public class Compra {

   private int numeroDeFactura;
   private int cantidad;
   private double valorDeCompra;
   private double impuesto;
   private double totalPagar;
   private String fechaDeCompra;
   private int serializado;
   private int proveedorID;

   public Compra(int numeroDeFactura, int cantidad, double valorDeCompra, double impuesto, double totalPagar,  String fechaDeCompra, int serializado, int proveedorID) {
       this.numeroDeFactura = numeroDeFactura;
       this.cantidad = cantidad;
       this.valorDeCompra = valorDeCompra;
       this.impuesto = impuesto;
       this.totalPagar = totalPagar;
       this.fechaDeCompra = fechaDeCompra;
       this.serializado = serializado;
       this.proveedorID = proveedorID;
   }

   public Compra() {
   }

   // getters and setters

    public int getNumeroDeFactura() {
        return numeroDeFactura;
    }

    public void setNumeroDeFactura(int numeroDeFactura) {
        this.numeroDeFactura = numeroDeFactura;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getValorDeCompra() {
        return valorDeCompra;
    }

    public void setValorDeCompra(double valorDeCompra) {
        this.valorDeCompra = valorDeCompra;
    }

    public double getImpuesto() {
        return impuesto;
    }

    public void setImpuesto(double impuesto) {
        this.impuesto = impuesto;
    }

    public double getTotalPagar() {
        return totalPagar;
    }

    public void setTotalPagar(double totalPagar) {
        this.totalPagar = totalPagar;
    }
    public String  getFechaDeCompra() {
        return fechaDeCompra;
    }

    public void setFechaDeCompra(String  fechaDeCompra) {
        this.fechaDeCompra = fechaDeCompra;
    }

    public int getSerializado() {
        return serializado;
    }

    public void setSerializado(int serializado) {
        this.serializado = serializado;
    }

    public int getProveedorID() {
        return proveedorID;
    }

    public void setProveedorID(int proveedorID) {
        this.proveedorID = proveedorID;
    }
}

