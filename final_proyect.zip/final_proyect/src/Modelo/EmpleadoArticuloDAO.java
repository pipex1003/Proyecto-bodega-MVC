package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class EmpleadoArticuloDAO {

    private Connection conexion;

    public EmpleadoArticuloDAO() {
        Conexion conectarBD = new Conexion();
        conexion = conectarBD.getConexion();
    }

   public void guardarEmpleadoArticulo(EmpleadoArticulo empleadoArticulo, String fecha_entrega) {
   String query = "INSERT INTO EmpleadoArticulo(Serializado, empleadoID, fecha_entrega) VALUES(?, ?, ?)";
   try (PreparedStatement statement = conexion.prepareStatement(query)) {
       statement.setInt(1, empleadoArticulo.getSerializado());
       statement.setInt(2, empleadoArticulo.getEmpleadoID());
       statement.setString(3, fecha_entrega);
       statement.executeUpdate();
   } catch (SQLException e) {
       e.printStackTrace();
   }
}


    public String buscarEmpleadoArticulo(int Serializado, int empleadoID) {
        String query = "SELECT Serializado, empleadoID FROM EmpleadoArticulo WHERE Serializado = ? AND empleadoID = ?";
        StringBuilder resultado = new StringBuilder();

        try (PreparedStatement statement = conexion.prepareStatement(query)) {
            statement.setInt(1, Serializado);
            statement.setInt(2, empleadoID);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    int Serializadobd = resultSet.getInt("Serializado");
                    int empleadoIDbd = resultSet.getInt("empleadoID");

                    // Concatenar los valores separados por comas
                    resultado.append(Serializadobd).append(", ");
                    resultado.append(empleadoIDbd).append(", ");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resultado.toString();
    }

    public void eliminarEmpleadoArticulo(int Serializado, int empleadoID) {
   String query = "DELETE FROM EmpleadoArticulo WHERE Serializado = ? AND empleadoID = ?";
   try (PreparedStatement statement = conexion.prepareStatement(query)) {
       statement.setInt(1, Serializado);
       statement.setInt(2, empleadoID);
       statement.executeUpdate();
   } catch (SQLException e) {
       e.printStackTrace();
   }

   // Get the current date
   java.util.Date currentDate = Calendar.getInstance().getTime();
   java.sql.Date ourJavaDateObject = new java.sql.Date(currentDate.getTime());

   // Insert a new row into the EmpleadoArticuloDevolucion table
   String queryDevolucion = "INSERT INTO EmpleadoArticuloDevolucion(Serializado, empleadoID, fecha_devolucion) VALUES(?, ?, ?)";
   try (PreparedStatement statementDevolucion = conexion.prepareStatement(queryDevolucion)) {
       statementDevolucion.setInt(1, Serializado);
       statementDevolucion.setInt(2, empleadoID);
       statementDevolucion.setDate(3, ourJavaDateObject);
       statementDevolucion.executeUpdate();
   } catch (SQLException e) {
       e.printStackTrace();
   }

    }

    public void modificarEmpleadoArticulo(EmpleadoArticulo empleadoArticulo) {
        String query = "UPDATE EmpleadoArticulo SET Serializado = ?, empleadoID = ?, fecha_entrega = ? WHERE Serializado = ? AND empleadoID = ?";

        try (PreparedStatement statement = conexion.prepareStatement(query)) {
            statement.setInt(1, empleadoArticulo.getSerializado());
            statement.setInt(2, empleadoArticulo.getEmpleadoID());
            statement.setString(3, empleadoArticulo.getFecha_entrega());
            statement.setInt(4, empleadoArticulo.getSerializado());
            statement.setInt(5, empleadoArticulo.getEmpleadoID());

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void llenarTablaEmpleadoArticulos(JTable tablaDatos) {
        try {
            String sql = "SELECT EmpleadoArticulo.Serializado, EmpleadoArticulo.empleadoID, empleados.Nombre AS NombreEmpleado, Articulos.Nombre AS NombreArticulo, EmpleadoArticulo.fecha_entrega " +
                    "FROM EmpleadoArticulo " +
                    "INNER JOIN empleados ON EmpleadoArticulo.empleadoID = empleados.empleadoID " +
                    "INNER JOIN Articulos ON EmpleadoArticulo.Serializado = Articulos.Serializado";
            PreparedStatement statement = conexion.prepareStatement(sql);

            ResultSet resultado = statement.executeQuery();

            DefaultTableModel modelo = new DefaultTableModel();
            tablaDatos.setModel(modelo);

            modelo.addColumn("Serializado");
            modelo.addColumn("empleadoID");
            modelo.addColumn("NombreEmpleado");
            modelo.addColumn("NombreArticulo");
            modelo.addColumn("fecha_entrega");

            while (resultado.next()) {
                Object[] fila = new Object[5];
                for (int i = 0; i < 5; i++) {
                    fila[i] = resultado.getObject(i + 1);
                }
                modelo.addRow(fila);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    public void llenarTablaEmpleadoArticuloDevolucion(JTable tablaDatos) {
   try {
       String sql = "SELECT EmpleadoArticuloDevolucion.Serializado, EmpleadoArticuloDevolucion.empleadoID, empleados.Nombre AS NombreEmpleado, Articulos.Nombre AS NombreArticulo, EmpleadoArticuloDevolucion.fecha_devolucion " +
               "FROM EmpleadoArticuloDevolucion " +
               "INNER JOIN empleados ON EmpleadoArticuloDevolucion.empleadoID = empleados.empleadoID " +
               "INNER JOIN Articulos ON EmpleadoArticuloDevolucion.Serializado = Articulos.Serializado";
       PreparedStatement statement = conexion.prepareStatement(sql);

       ResultSet resultado = statement.executeQuery();

       DefaultTableModel modelo = new DefaultTableModel();
       tablaDatos.setModel(modelo);

       modelo.addColumn("Serializado");
       modelo.addColumn("empleadoID");
       modelo.addColumn("NombreEmpleado");
       modelo.addColumn("NombreArticulo");
       modelo.addColumn("fecha_devolucion");

       while (resultado.next()) {
           Object[] fila = new Object[5];
           for (int i = 0; i < 5; i++) {
               fila[i] = resultado.getObject(i + 1);
           }
           modelo.addRow(fila);
       }

   } catch (SQLException ex) {
       ex.printStackTrace();
   }
}

}
