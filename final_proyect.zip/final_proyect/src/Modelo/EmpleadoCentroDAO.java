/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author ANDRES AVILA
 */



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class EmpleadoCentroDAO {

   private Connection conexion;

   public EmpleadoCentroDAO() {
       Conexion conectarBD = new Conexion();
       conexion = conectarBD.getConexion();
   }

   public void guardarEmpleadoCentroDeCosto(EmpleadoCentro empleadoCentroDeCosto) {
       String query = "INSERT INTO EmpleadoCentroDeCosto(EmpleadoID, CentroDeCostoID) VALUES(?, ?)";
       try (PreparedStatement statement = conexion.prepareStatement(query)) {
           statement.setInt(1, empleadoCentroDeCosto.getEmpleadoID());
           statement.setInt(2, empleadoCentroDeCosto.getCentroDeCostoID());
           statement.executeUpdate();
       } catch (SQLException e) {
           e.printStackTrace();
       }
   }

   public String buscarEmpleadoCentroDeCosto(int empleadoID, int centroDeCostoID) {
       String query = "SELECT EmpleadoID, CentroDeCostoID FROM EmpleadoCentroDeCosto WHERE EmpleadoID = ? AND CentroDeCostoID = ?";
       StringBuilder resultado = new StringBuilder();

       try (PreparedStatement statement = conexion.prepareStatement(query)) {
           statement.setInt(1, empleadoID);
           statement.setInt(2, centroDeCostoID);

           try (ResultSet resultSet = statement.executeQuery()) {
               while (resultSet.next()) {
                  int empleadoIDbd = resultSet.getInt("EmpleadoID");
                  int centroDeCostoIDbd = resultSet.getInt("CentroDeCostoID");

                  // Concatenar los valores separados por comas
                  resultado.append(empleadoIDbd).append(", ");
                  resultado.append(centroDeCostoIDbd).append(", ");
               }
           }
       } catch (SQLException e) {
           e.printStackTrace();
       }
       return resultado.toString();
   }

   public void eliminarEmpleadoCentroDeCosto(int empleadoID, int centroDeCostoID) {
       String query = "DELETE FROM EmpleadoCentroDeCosto WHERE EmpleadoID = ? AND CentroDeCostoID = ?";

       try (PreparedStatement statement = conexion.prepareStatement(query)) {
           statement.setInt(1, empleadoID);
           statement.setInt(2, centroDeCostoID);
           statement.executeUpdate();
       } catch (SQLException e) {
           e.printStackTrace();
       }
   }

   public void modificarEmpleadoCentroDeCosto(EmpleadoCentro empleadoCentroDeCosto) {
       String query = "UPDATE EmpleadoCentroDeCosto SET EmpleadoID = ?, CentroDeCostoID = ? WHERE EmpleadoID = ? AND CentroDeCostoID = ?";

       try (PreparedStatement statement = conexion.prepareStatement(query)) {
           statement.setInt(1, empleadoCentroDeCosto.getEmpleadoID());
           statement.setInt(2, empleadoCentroDeCosto.getCentroDeCostoID());
           statement.setInt(3, empleadoCentroDeCosto.getEmpleadoID());
           statement.setInt(4, empleadoCentroDeCosto.getCentroDeCostoID());

           statement.executeUpdate();
       } catch (SQLException e) {
           e.printStackTrace();
       }
   }

 public void llenarTablaEmpleadoCentroCostos(JTable tablaDatos) {
   try {
       String sql = "SELECT EmpleadoCentroDeCosto.EmpleadoID, EmpleadoCentroDeCosto.CentroDeCostoID, empleados.Nombre AS NombreEmpleado, Centro_de_costo.Nombre AS NombreCentroDeCosto " +
                   "FROM EmpleadoCentroDeCosto " +
                   "INNER JOIN empleados ON EmpleadoCentroDeCosto.EmpleadoID = empleados.empleadoID " +
                   "INNER JOIN Centro_de_costo ON EmpleadoCentroDeCosto.CentroDeCostoID = Centro_de_costo.ID_centro_de_costo";
       PreparedStatement statement = conexion.prepareStatement(sql);

       ResultSet resultado = statement.executeQuery();

       DefaultTableModel modelo = new DefaultTableModel();
       tablaDatos.setModel(modelo);

       modelo.addColumn("EmpleadoID");
       modelo.addColumn("CentroDeCostoID");
       modelo.addColumn("NombreEmpleado");
       modelo.addColumn("NombreCentroDeCosto");

       while (resultado.next()) {
           Object[] fila = new Object[4];
           for (int i = 0; i < 4; i++) {
               fila[i] = resultado.getObject(i + 1);
           }
           modelo.addRow(fila);
       }

   } catch (SQLException ex) {
       ex.printStackTrace();
   }
}


   }





