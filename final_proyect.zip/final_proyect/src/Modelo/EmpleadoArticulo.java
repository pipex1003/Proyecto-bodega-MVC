package Modelo;

public class EmpleadoArticulo {

    private int Serializado;
    private int empleadoID;
    private String fecha_entrega;

    public EmpleadoArticulo() {
    }

    public EmpleadoArticulo(int Serializado, int empleadoID, String fecha_entrega) {
        this.Serializado = Serializado;
        this.empleadoID = empleadoID;
        this.fecha_entrega = fecha_entrega;
    }

    public int getSerializado() {
        return Serializado;
    }

    public void setSerializado(int Serializado) {
        this.Serializado = Serializado;
    }

    public int getEmpleadoID() {
        return empleadoID;
    }

    public void setEmpleadoID(int empleadoID) {
        this.empleadoID = empleadoID;
    }

    public String getFecha_entrega() {
        return fecha_entrega;
    }

    public void setFecha_entrega(String fecha_entrega) {
        this.fecha_entrega = fecha_entrega;
    }
}
