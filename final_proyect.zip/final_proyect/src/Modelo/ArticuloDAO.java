/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.awt.Component;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ArticuloDAO {

    private Connection conexion;

    public ArticuloDAO() {
        Conexion conectaBD = new Conexion();
        conexion = conectaBD.getConexion();
    }
    

    public void ingresarArticulo(Articulo articulo) {
    try {
        String id = String.valueOf(articulo.getSerializado());

        if (id.contains(".*[a-zA-Z].*")) {
            System.out.println("El serializado contiene una letra. Por favor, ingrese un serializado válido sin letras.");
            return; // Salir del método sin continuar
        }

        String sql = "INSERT INTO Articulos (Serializado, Descripcion, PorcentajeImpuesto,nombre, Categoria, VidaUtil) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement statement = conexion.prepareStatement(sql);
        statement.setString(2, articulo.getDescripcion());
        statement.setDouble(3, articulo.getImpuesto());
        statement.setString(4, articulo.getNombre());
        statement.setInt(1, articulo.getSerializado());
        statement.setString(5, articulo.getCategoria());
        statement.setInt(6, articulo.getVidaUtil());

        int rowsInserted = statement.executeUpdate();
        if (rowsInserted > 0) {
            System.out.println("Nuevo Articulo agregado correctamente!");
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
}

    
    public void modificarArticulo(Articulo articulo) {
        try {
            String sql = "UPDATE Articulos SET Descripcion=?, PorcentajeImpuesto=?, nombre=?, Serializado=?, Categoria=?, VidaUtil=? WHERE ArticuloID=?";
               PreparedStatement statement = conexion.prepareStatement(sql);
        statement.setString(1, articulo.getDescripcion());
        statement.setDouble(2, articulo.getImpuesto());
        statement.setString(3, articulo.getNombre());
        statement.setInt(4, articulo.getSerializado());
        statement.setString(5, articulo.getCategoria());
        statement.setInt(6, articulo.getVidaUtil());

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Articulo modificado correctamente!");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void borrarArticulo(int ArticuloID) {
         try {
    
     boolean articuloNoRegistrado = articuloNoRegistradoEnCompras(ArticuloID);

    if (articuloNoRegistrado) {
        String sql = "DELETE FROM Articulos WHERE ArticuloID=?";
        PreparedStatement statement = conexion.prepareStatement(sql);
        statement.setInt(1, ArticuloID);

        int rowsDeleted = statement.executeUpdate();
        if (rowsDeleted > 0) {
            Component vista = null;
             JOptionPane.showMessageDialog(vista, "articulo eliminado correctamente.", "eliminar articulo", JOptionPane.INFORMATION_MESSAGE);
        }
    } else {
         Component vista = null;
        JOptionPane.showMessageDialog(vista, "el articulo se encuentra en una compra y no puede ser eliminado.", "eliminar articulo", JOptionPane.INFORMATION_MESSAGE);
    }
} catch (SQLException ex) {
    ex.printStackTrace();
}
    }

    public void llenarTablaArticulos(JTable tablaArticulos) {
        try {
            
            String sql = "SELECT * FROM Articulos";
            PreparedStatement statement = conexion.prepareStatement(sql);

            ResultSet resultado = statement.executeQuery();

            DefaultTableModel modelo = new DefaultTableModel();
            tablaArticulos.setModel(modelo);

            modelo.addColumn("Descripcion");
            modelo.addColumn("Serie");
            modelo.addColumn("PorcentajeImpuesto");
            modelo.addColumn("nombre");
            modelo.addColumn("Categoria");
            modelo.addColumn("VidaUtil");

            while (resultado.next()) {
                Object[] fila = new Object[6];
                for (int i = 0; i < 6; i++) {
                    fila[i] = resultado.getObject(i + 1);
                }
                modelo.addRow(fila);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

  public boolean articuloNoRegistradoEnCompras(int articuloID) {
        try {
            // Realizar la consulta para verificar si el artículo no está en ninguna compra
            String sql = "SELECT COUNT(*) FROM Compra WHERE Serializado=?";
            try (PreparedStatement statement = conexion.prepareStatement(sql)) {
                statement.setInt(1, articuloID);

                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        int count = resultSet.getInt(1);
                        return count == 0; // Retorna true si el artículo no está en ninguna compra
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false; // En caso de error, asumimos que el artículo no está registrado en ninguna compra
    }
    public String buscarArticulo(int articuloID) {
    String query = "SELECT serializado, Descripcion, PorcentajeImpuesto, nombre, Categoria, VidaUtil FROM Articulos WHERE serializado = ?";
    StringBuilder resultado = new StringBuilder();

    try (PreparedStatement statement = conexion.prepareStatement(query)) {
        statement.setInt(1, articuloID);

        try (ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                int id = resultSet.getInt("serializado");
                String descripcion = resultSet.getString("Descripcion");
                double porcentajeImpuesto = resultSet.getDouble("PorcentajeImpuesto");
                String nombre = resultSet.getString("nombre");
                String categoria = resultSet.getString("Categoria");
                int vidaUtil = resultSet.getInt("VidaUtil");

                resultado.append(id).append(", ");
                resultado.append(descripcion).append(", ");
                resultado.append(porcentajeImpuesto).append(", ");
                resultado.append(nombre).append(", ");
                resultado.append(categoria).append(", ");
                resultado.append(vidaUtil).append(", ");
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    if (resultado.length() > 0) {
        resultado.delete(resultado.length() - 2, resultado.length());
    }

    return resultado.toString();
}

    
}
