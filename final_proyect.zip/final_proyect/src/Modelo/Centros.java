/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author SER_9
 */
public class Centros {

    private String descripcion;
    private String encargado;
    private String nombre;
    private String ubicacion;
    private int id_centros;

    // Constructor
    public Centros(int id_centros,String descripcion,String encargado, String nombre, String ubicacion) {
        this.id_centros = id_centros;
        this.descripcion = descripcion;
        this.encargado = encargado;
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        
    }
    public Centros() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEncargado() {
        return encargado;
    }

    public void setEncargado(String encargado) {
        this.encargado = encargado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public int getId_centros() {
        return id_centros;
    }

    public void setId_centros(int id_centros) {
        this.id_centros = id_centros;
    }
}
    