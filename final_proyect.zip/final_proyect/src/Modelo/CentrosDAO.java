/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author SER_9
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class CentrosDAO {

    private Connection conexion;

    public CentrosDAO() {
        Conexion conectaBD = new Conexion();
        conexion = conectaBD.getConexion();
    }

    public void CrearCentro(Centros centro) {
    try {
        String id = String.valueOf(centro.getId_centros());

        if (id.contains(".*[a-zA-Z].*")) {
            System.out.println("El ID contiene una letra. Por favor, ingrese un ID válido sin letras.");
            return; // Salir del método sin continuar
        }

        String sql = "INSERT INTO centro_de_costo (ID_centro_de_costo, Nombre, Descripcion, Encargado, Ubicacion) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement statement = conexion.prepareStatement(sql);
        statement.setString(2, centro.getNombre());
        statement.setString(3, centro.getDescripcion());
        statement.setString(4, centro.getEncargado());
        statement.setInt   (1, centro.getId_centros());
        statement.setString(5, centro.getUbicacion());


        int rowsInserted = statement.executeUpdate();
        if (rowsInserted > 0) {
            System.out.println("Nuevo centro agregado correctamente!");
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
}

    
    public void EditarCentro(Centros centro) {
        try {
            String sql = "UPDATE centro_de_costo SET  Descripcion=?, Nombre=?, Encargado=?, Ubicacion=?  WHERE ID_centro_de_costo=?";
               PreparedStatement statement = conexion.prepareStatement(sql);
        
        statement.setString(3, centro.getDescripcion());
        statement.setString(2, centro.getNombre());
        statement.setString(4, centro.getEncargado());
        statement.setString(5, centro.getUbicacion());
        

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Centro modificado correctamente!");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void EliminarCentro(int ID_centro_de_costo) {
        try {
            String sql = "DELETE FROM centro_de_costo WHERE ID_centro_de_costo=?";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setInt(1, ID_centro_de_costo);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Centro eliminado correctamente!");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void llenarTablaCentros(JTable tablacentros) {
        try {
            
            String sql = "SELECT * FROM centro_de_costo";
            PreparedStatement statement = conexion.prepareStatement(sql);

            ResultSet resultado = statement.executeQuery();

            DefaultTableModel modelocentro = new DefaultTableModel();
            tablacentros.setModel(modelocentro);
            
            modelocentro.addColumn("ID_centro_de_costo");
            modelocentro.addColumn("Descripcion");
            modelocentro.addColumn("Nombre");
            modelocentro.addColumn("Encargado");
            modelocentro.addColumn("Ubicacion");
            
            
            

           while (resultado.next()) {
            Object[] fila = new Object[5];
                for (int i = 0; i < 5; i++) {
                     fila[i] = resultado.getObject(i + 1);
                     }
            modelocentro.addRow(fila);
}

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public String buscarCentro(int idCentro) {
        String query = "SELECT ID_centro_de_costo, Descripcion, Nombre, Encargado, Ubicacion FROM centro_de_costo WHERE ID_centro_de_costo = ?";
        StringBuilder resultado = new StringBuilder();

        try (PreparedStatement statement = conexion.prepareStatement(query)) {
            statement.setInt(1, idCentro);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    int id = resultSet.getInt("ID_centro_de_costo");
                    String descripcion = resultSet.getString("Descripcion");
                    String nombre = resultSet.getString("Nombre");
                    String encargado = resultSet.getString("Encargado");
                    String ubicacion = resultSet.getString("Ubicacion");

                    resultado.append(id).append(", ");
                    resultado.append(descripcion).append(", ");
                    resultado.append(nombre).append(", ");
                    resultado.append(encargado).append(", ");
                    resultado.append(ubicacion).append(", ");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (resultado.length() > 0) {
            resultado.delete(resultado.length() - 2, resultado.length());
        }

        return resultado.toString();
    }


}



