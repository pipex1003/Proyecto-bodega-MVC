package Modelo;

import java.sql.Date;

public class Empleado {

    private int empleadoID;
    private String nombre;
    private String correo;
    private int identificacion;
    private String fechaNacimiento;
    private int telefono;
    private String fechaIngreso;
    private double salario;
    private String estado;
    private String usuario;
    private String clave;
    private String rol;
    private int idCentroDeCosto;

    public Empleado(int empleadoID, String nombre, String correo, int identificacion, String fechaNacimiento, int telefono, String fechaIngreso, double salario, String estado, String usuario, String clave, String rol) {
        this.empleadoID = empleadoID;
        this.nombre = nombre;
        this.correo = correo;
        this.identificacion = identificacion;
        this.fechaNacimiento = fechaNacimiento;
        this.telefono = telefono;
        this.fechaIngreso = fechaIngreso;
        this.salario = salario;
        this.estado = estado;
        this.usuario = usuario;
        this.clave = clave;
        this.rol = rol;
        this.idCentroDeCosto = idCentroDeCosto;
    }

    public int getEmpleadoID() {
        return empleadoID;
    }

    public void setEmpleadoID(int empleadoID) {
        this.empleadoID = empleadoID;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public int getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(int identificacion) {
        this.identificacion = identificacion;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(String fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    // Getter y Setter para el nuevo campo usuario
    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    // Getter y Setter para el nuevo campo clave
    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    // Getter y Setter para el nuevo campo rol
    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    // Getter y Setter para el nuevo campo idCentroDeCosto
    public int getIdCentroDeCosto() {
        return idCentroDeCosto;
    }

    public void setIdCentroDeCosto(int idCentroDeCosto) {
        this.idCentroDeCosto = idCentroDeCosto;
    }

    // Resto de los métodos existentes en tu clase...
}
