/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.awt.Component;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ANDRES AVILA
 */
public class ProveedorDAO {
  
    private Connection conexion;
    
    public ProveedorDAO() {
        Conexion conectaBD = new Conexion();
        conexion = conectaBD.getConexion();
    }
  
    public void ingresarProveedor(Proveedor proveedor) {
        try {
            String sql = "INSERT INTO Proveedores (ProveedorID, Nombre, Telefono, Direccion) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setInt(1, proveedor.getProveedorID());
            statement.setString(2, proveedor.getNombre());
            statement.setInt(3, proveedor.getTelefono());
            statement.setString(4, proveedor.getDireccion());

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Nuevo proveedor agregado correctamente!");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
  public String buscarProveedor(int proveedorID) {
        String query = "SELECT ProveedorID, Nombre, Telefono, Direccion FROM Proveedores WHERE ProveedorID = ?";
        StringBuilder resultado = new StringBuilder();
        try (PreparedStatement statement = conexion.prepareStatement(query)) {
            statement.setInt(1, proveedorID);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    int proveedorIDbd = resultSet.getInt("ProveedorID");
                    String nombre = resultSet.getString("Nombre");
                    int telefono = resultSet.getInt("Telefono");
                    String direccion = resultSet.getString("Direccion");

                    // Concatenar los valores separados por comas
                    resultado.append(proveedorIDbd).append(", ");
                    resultado.append(nombre).append(", ");
                    resultado.append(telefono).append(", ");
                    resultado.append(direccion).append(", ");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Eliminar la última coma y espacio si existen
        if (resultado.length() > 0) {
            resultado.delete(resultado.length() - 2, resultado.length());
        }

        return resultado.toString();
    }

    public void borrarproveedor(int ProveedorID) {
        try {
            boolean proveedorNoRegistrado = proveedorNoRegistradoEnCompras(ProveedorID);
             if (proveedorNoRegistrado) {
            String sql = "DELETE FROM Proveedores WHERE ProveedorID=?";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setInt(1, ProveedorID);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                Component vista = null;
             JOptionPane.showMessageDialog(vista, "articulo eliminado correctamente.", "eliminar articulo", JOptionPane.INFORMATION_MESSAGE);
        }
             }else {
         Component vista = null;
        JOptionPane.showMessageDialog(vista, "el proveedor se encuentra en una venta y no puede ser eliminado.", "eliminar proveedor", JOptionPane.INFORMATION_MESSAGE);
    }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
  public void modificarProveedor(Proveedor proveedor) throws Exception {
    // Comprobamos si el usuario que está intentando actualizar los datos es administrador.
    UsuariosDAO usuariosDAO = new UsuariosDAO();
    Usuarios usuarioActual = usuariosDAO.Login(Usuarios.getUsuario(), Usuarios.getClave());

    try {
        String sql;
        PreparedStatement statement;

        // Verificar si el usuario actual es administrador o no
        if (usuarioActual.getRol().equals("administrador")) {
            // Si es administrador, permitir modificar todos los campos
            sql = "UPDATE Proveedores SET Nombre=?, Telefono=?, Direccion=? WHERE ProveedorID=?";
            statement = conexion.prepareStatement(sql);
            statement.setString(1, proveedor.getNombre());
            statement.setInt(2, proveedor.getTelefono());
            statement.setString(3, proveedor.getDireccion());
            statement.setInt(4, proveedor.getProveedorID());
        } else {
            // Si no es administrador, permitir modificar solo los campos Nombre, Telefono y Direccion
            sql = "UPDATE Proveedores SET Nombre=?, Telefono=?, Direccion=? WHERE ProveedorID=?";
            statement = conexion.prepareStatement(sql);
            statement.setString(1, proveedor.getNombre());
            statement.setInt(2, proveedor.getTelefono());
            statement.setString(3, proveedor.getDireccion());
            statement.setInt(4, proveedor.getProveedorID());
        }

        int rowsUpdated = statement.executeUpdate();
        if (rowsUpdated > 0) {
            System.out.println("Proveedor modificado correctamente!");
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
}


    public void llenarTablaProveedor(JTable tablaProveedores) {
        try {
            String sql = "SELECT * FROM Proveedores";
            PreparedStatement statement = conexion.prepareStatement(sql);

            ResultSet resultado = statement.executeQuery();

            DefaultTableModel modelo = new DefaultTableModel();
            tablaProveedores.setModel(modelo);

            modelo.addColumn("ProveedorID");
            modelo.addColumn("Nombre");
            modelo.addColumn("Telefono");
            modelo.addColumn("Direccion");

            while (resultado.next()) {
                Object[] fila = new Object[4];
                for (int i = 0; i < 4; i++) {
                    fila[i] = resultado.getObject(i + 1);
                }
                modelo.addRow(fila);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
     public boolean  proveedorNoRegistradoEnCompras(int proveedorID) {
        try {
            // Realizar la consulta para verificar si el artículo no está en ninguna compra
            String sql = "SELECT COUNT(*) FROM Compra WHERE  proveedorID=?";
            try (PreparedStatement statement = conexion.prepareStatement(sql)) {
                statement.setInt(1,proveedorID);

                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        int count = resultSet.getInt(1);
                        return count == 0; // Retorna true si el artículo no está en ninguna compra
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false; // En caso de error, asumimos que el artículo no está registrado en ninguna compra
    }
     public int CalcularComisionEmple(int empleadoID) {
   int cantidadVentas = 0;

   try {
       String sql = "SELECT COUNT(*) " +
                   "FROM compra c " +
                   "WHERE c.proveedorID = ?";
       try (PreparedStatement preparedStatement = conexion.prepareStatement(sql)) {
           preparedStatement.setInt(1, empleadoID);
           try (ResultSet resultSet = preparedStatement.executeQuery()) {
               if (resultSet.next()) {
                  cantidadVentas = resultSet.getInt(1);
               }
           }
       }
   } catch (SQLException e) {
       e.printStackTrace(); // Manejo básico de excepciones, reemplaza con un manejo más robusto en un entorno de producción.
   }
   return cantidadVentas;
}
public int calcularComision(int empleadoID) {
    int cantidadVentas = CalcularComisionEmple(empleadoID);
    int comision = cantidadVentas * 10000;

    return comision;
}
} 

