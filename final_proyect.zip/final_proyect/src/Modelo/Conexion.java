/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author ANDRES AVILA
 */
import javax.swing.JOptionPane;
public class Conexion {
    Connection con;
    public Connection getConexion(){
        try{
            String db= "jdbc:mysql://localhost:3306/periquito?";
            con= DriverManager.getConnection(db,"root","botellita10");
        }catch(SQLException e){
        JOptionPane.showMessageDialog(null, "error al conectar"+e.toString());
    }
    return con;
   }
}
