/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author ANDRES AVILA
 */
package Modelo;

public class Articulo {

    private String descripcion;
    private double impuesto;
    private String nombre;
    private int serializado;
  //  private String tipo;
    private String categoria;
    private int vidaUtil;

    // Constructor
    public Articulo(int serializado, String descripcion, double impuesto, String nombre, String categoria, int vidaUtil) {
        this.descripcion = descripcion;
        this.impuesto = impuesto;
        this.nombre = nombre;
        this.serializado = serializado;
     //   this.tipo = tipo;
        this.categoria = categoria;
        this.vidaUtil = vidaUtil;
    }

    public Articulo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Getters y setters
 
    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getImpuesto() {
        return impuesto;
    }

    public void setImpuesto(double impuesto) {
        this.impuesto = impuesto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public int getSerializado() {
        return serializado;
    }

    public void setSerializado(int serializado) {
        this.serializado = serializado;
    }

    


    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public int getVidaUtil() {
        return vidaUtil;
    }

    public void setVidaUtil(int vidaUtil) {
        this.vidaUtil = vidaUtil;
    }
}

