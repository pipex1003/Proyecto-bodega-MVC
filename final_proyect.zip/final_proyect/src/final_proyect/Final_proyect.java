/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package final_proyect;

/**
 *
 * @author ANDRES AVILA
 */
import Vista.FormularioLogin;
public class Final_proyect {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FormularioLogin FormularioL =new FormularioLogin();
        FormularioL.setVisible(true);
    }
    
}
