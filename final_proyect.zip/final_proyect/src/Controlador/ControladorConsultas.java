/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.ConsultarSQL;
import Vista.Consultas;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Josed
 */
public class ControladorConsultas implements ActionListener {

    Consultas objetoVista;
    ConsultarSQL objetoModelo;
    DefaultTableModel modelo = new DefaultTableModel();
    String sql = "";

    public ControladorConsultas() {
        objetoVista = new Consultas();
        objetoVista.setVisible(true);
        objetoVista.setLocationRelativeTo(null);
        objetoVista.getBotonConsulta().addActionListener(this);
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == objetoVista.getBotonConsulta()) {
            objetoModelo = new ConsultarSQL();
            sql = objetoVista.getTxtareaconsulta().getText();
            modelo = (DefaultTableModel) objetoVista.getTablaconsulta().getModel();
            
            int filas = objetoVista.getTablaconsulta().getRowCount();
            for (int i = 0; i < filas; i++)
                modelo.removeRow(0);
            
            modelo = objetoModelo.consultar(sql);
            objetoVista.getTablaconsulta().setModel(modelo);
        }
    }
}