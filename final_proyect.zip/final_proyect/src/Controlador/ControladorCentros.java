/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Controlador;


import Modelo.Centros;
import Modelo.CentrosDAO;
import Vista.FormularioCentros_Costo;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ANDRES AVILA
 */
public class ControladorCentros  implements ActionListener {

    private FormularioCentros_Costo vista;
    private CentrosDAO bdCentros;
    private DefaultTableModel modelo;
    private Centros centro;

       public ControladorCentros() {
        vista = new FormularioCentros_Costo();
        bdCentros = new CentrosDAO();
        vista.setVisible(true);
        vista.getBtnCrear().addActionListener(this);
        vista.getBtnEliminar().addActionListener(this);
        vista.getBtnModificar().addActionListener(this);
        vista.getBtnbuscar().addActionListener(this);
        modelo = (DefaultTableModel) vista.getTablaCentros().getModel();
        bdCentros.llenarTablaCentros(vista.getTablaCentros());
        this.vista.setLocationRelativeTo(null);
    }
   
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.getBtnCrear()) {
            System.out.println("Guardando articulo");
            crearcentro();
        } else if (e.getSource() == vista.getBtnModificar()) {
             System.out.println("Modificando articulo");
            editarcentro();
        } else if (e.getSource() == vista.getBtnEliminar()) {
            System.out.println("Eliminando articulo");
            eliminarcentro();
        }else if (e.getSource() == vista.getBtnbuscar()) {
        System.out.println("Buscando centro");
        buscarCentro();
        }
    }
   
    private void crearcentro() {
        //Traer los datos de la vista
        int id_centro = Integer.parseInt(vista.getTxtIDcentro().getText());
        String descripcion = vista.getTxtDescripcioncentro().getText();
        String nombre = vista.getTxtNombrecentro().getText();
        String ubicacion = vista.getTxtUbicacioncentro().getText();
        String encargado = vista.getTxtResponsablecentro().getText();
        

        centro = new Centros(id_centro,descripcion,encargado,nombre,ubicacion);

        bdCentros.CrearCentro(centro);
        limpiarCampos();

        // Llenar la tabla con los datos de la base de datos
        bdCentros.llenarTablaCentros(vista.getTablaCentros());
        JOptionPane.showMessageDialog(vista, "centro de costos agregado correctamente.");
    }
   
    private void editarcentro() {
        //Traer el id a modificar
        int id_centro = Integer.parseInt(vista.getTxtIDcentro().getText());

        //Traer los datos de la vista
        int id_centros= Integer.parseInt(vista.getTxtIDcentro().getText());
        String descripcion = vista.getTxtDescripcioncentro().getText();
        String nombre = vista.getTxtNombrecentro().getText();
        String encargado = vista.getTxtResponsablecentro().getText();
        String ubicacion = vista.getTxtUbicacioncentro().getText();
       
        centro = new Centros(id_centros,descripcion,encargado,nombre,ubicacion);
        
        bdCentros.EditarCentro(centro);
        limpiarCampos();

        // Llenar la tabla con los datos de la base de datos
        bdCentros.llenarTablaCentros(vista.getTablaCentros());
    }
   
    private void eliminarcentro() {
        //Traer el id a eliminar
        int idSeleccionado = Integer.parseInt(vista.getTxtIDcentro().getText());
        bdCentros.EliminarCentro(idSeleccionado);
        limpiarCampos();

        // Llenar la tabla con los datos de la base de datos
        bdCentros.llenarTablaCentros(vista.getTablaCentros());
        JOptionPane.showMessageDialog(vista, "centro eliminado correctamente.");
    }
   
    private void limpiarCampos() {
        vista.getTxtIDcentro().setText(null);
        vista.getTxtDescripcioncentro().setText(null);
        vista.getTxtNombrecentro().setText(null);
        vista.getTxtResponsablecentro().setText(null);
        vista.getTxtUbicacioncentro().setText(null);
       
    }
  
public void iniciar() {
        vista.setVisible(true);
    }
private void buscarCentro() {
    try {
        int idCentro = Integer.parseInt(vista.getTxtIDcentro().getText());

        // Realizar la búsqueda del centro por su ID
        String centroEncontrado = bdCentros.buscarCentro(idCentro);

        // Verificar si se encontró algún centro
        if (!centroEncontrado.isEmpty()) {
            // Separar los valores del centro encontrados por comas
            String[] valoresCentro = centroEncontrado.split(", ");

            // Llenar los campos de texto con los valores del centro
            vista.getTxtIDcentro().setText(valoresCentro[0]);
            vista.getTxtDescripcioncentro().setText(valoresCentro[1]);
            vista.getTxtNombrecentro().setText(valoresCentro[2]);
            vista.getTxtResponsablecentro().setText(valoresCentro[3]);
            vista.getTxtUbicacioncentro().setText(valoresCentro[4]);

            // Additional fields can be filled here based on your data model
        } else {
            // No se encontró ningún centro con el ID especificado, limpiar los campos
            limpiarCampos();

            // Mostrar un mensaje indicando que no se encontró el centro
            JOptionPane.showMessageDialog(vista, "No se encontró ningún centro con el ID especificado.", "Búsqueda de Centro", JOptionPane.INFORMATION_MESSAGE);
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(vista, "Ingrese un ID válido.", "Búsqueda de Centro", JOptionPane.ERROR_MESSAGE);
    }
}

} 