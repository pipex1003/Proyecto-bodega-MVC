/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;


import Modelo.Conexion;
import Modelo.EmpleadoDAO;
import Modelo.Empleado;
import Modelo.Usuarios;
import Modelo.UsuariosDAO;
import Vista.FormularioEmpleados;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

import javax.swing.table.DefaultTableModel;

public class ControladorEmpleado implements ActionListener {

    private FormularioEmpleados vista;
    private EmpleadoDAO bdEmpleado;
    private DefaultTableModel modelo;
    private Usuarios usuarioActual;

    public ControladorEmpleado() {
        vista = new FormularioEmpleados();
        bdEmpleado = new EmpleadoDAO();
        vista.setVisible(true);
        this.vista.setLocationRelativeTo(null);
          // Verificar el estado del empleado que inició sesión
      //      String estadoEmpleado = usuarioActual.getEstado();

//            // Deshabilitar campos si el empleado que inició sesión está inactivo
//            if (estadoEmpleado.equals("inactivo")) {
//                deshabilitarCamposEmpleado();
//            }
        // Configurar el ActionListener para los botones
        vista.getBtnAgregar().addActionListener(this);
        vista.getBtnBuscar().addActionListener(this);
        vista.getBtnEditar().addActionListener(this);
        vista.getBtnEliminar().addActionListener(this);
        vista.getBtndeshabilitar().addActionListener(this);
        vista.getBtnhabilitar().addActionListener(this);
        vista.getBtncumpleaños().addActionListener(this);
      
        // Obtener el modelo de la tabla
        modelo = (DefaultTableModel) vista.getJtableEmpleados().getModel();
        // Llenar la tabla con los datos de la base de datos
        bdEmpleado.llenarTablaEmpleados(vista.getJtableEmpleados());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    if (e.getSource() == vista.getBtnAgregar()) {
        agregarEmpleado();
    } else if (e.getSource() == vista.getBtnBuscar()) {
        buscarEmpleados();
    } else if (e.getSource() == vista.getBtnEditar()) {
        try {
            editarEmpleado();
        } catch (Exception ex) {
            Logger.getLogger(ControladorEmpleado.class.getName()).log(Level.SEVERE, null, ex);
        }
    } else if (e.getSource() == vista.getBtnEliminar()) {
        eliminarEmpleado();
    } else if (e.getSource() == vista.getBtndeshabilitar()) {
        deshabilitarEmpleado();
    } else if (e.getSource() == vista.getBtncumpleaños()) {
        calcularBonoCumpleaños();
    }else if (e.getSource() == vista.getBtnhabilitar()) {
        habilitarEmpleado();
    }
}

//private void deshabilitarCamposEmpleado() {
//    vista.getEmpleadotxtid().setEnabled(false);
//    vista.getEmpleadotxtnombre().setEnabled(false);
//    vista.getEmpleadotxtemail().setEnabled(false);
//    vista.getEmpleadotxtcc().setEnabled(false);
//    vista.getEmpleadotxtFCumpleaños().setEnabled(false);
//    vista.getEmpleadotxttelefono().setEnabled(false);
//    vista.getEmpleadotxtfecha().setEnabled(false);
//    vista.getEmpleadotxtSalario().setEnabled(false);
//    vista.getTxtusuario().setEnabled(false);
//    vista.getTxtcontraseña().setEnabled(false);
//    vista.getTxtrol().setEnabled(false);
//    vista.getTxtcumpleaños().setEnabled(false);
//    vista.getBtnAgregar().setEnabled(false);
//    vista.getBtnBuscar().setEnabled(false);
//    vista.getBtnEditar().setEnabled(false);
//    vista.getBtnEliminar().setEnabled(false);
//    vista.getBtndeshabilitar().setEnabled(false);
//    vista.getBtncumpleaños().setEnabled(false);
//}
  private void agregarEmpleado() {
    try {
        // Obtener los valores de los campos de texto
        int empleadoID = Integer.parseInt(vista.getEmpleadotxtid().getText());
        String nombre = vista.getEmpleadotxtnombre().getText();
        String correo = vista.getEmpleadotxtemail().getText();
        int identificacion = Integer.parseInt(vista.getEmpleadotxtcc().getText());
        String fechaNacimientoStr = vista.getEmpleadotxtFCumpleaños().getText();
        int telefono = Integer.parseInt(vista.getEmpleadotxttelefono().getText());
        String fechaIngresoStr = vista.getEmpleadotxtfecha().getText();
        double salario = Double.parseDouble(vista.getEmpleadotxtSalario().getText());
        String estado = "activo";
        String usuario = vista.getTxtusuario().getText();
        String contraseña = new String(vista.getTxtcontraseña().getPassword());
        String rol = vista.getTxtrol().getText();
        // Verificar si el campo empleadoID está vacío
        if (empleadoID == 0) {
            // Mostrar un mensaje de error
            JOptionPane.showMessageDialog(vista, "Ingrese un ID para el empleado.", "Agregar Empleado", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Crear el objeto Empleado con los datos ingresados
        Empleado empleado = new Empleado(empleadoID, nombre, correo, identificacion, fechaNacimientoStr, telefono, fechaIngresoStr, salario, estado,usuario, contraseña,rol);

        // Agregar el empleado a la base de datos
        bdEmpleado.agregarEmpleado(empleado);

        // Limpiar los campos de texto
        limpiarCamposTexto();

        // Actualizar la tabla de empleados
        bdEmpleado.llenarTablaEmpleados(vista.getJtableEmpleados());
        JOptionPane.showMessageDialog(vista, "Empleado agregado correctamente.", "Agregar Empleado", JOptionPane.INFORMATION_MESSAGE);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(vista, "Ingrese valores numéricos válidos.", "Agregar Empleado", JOptionPane.ERROR_MESSAGE);
    }
}

   private void buscarEmpleados() {
    try {
        int empleadoID = Integer.parseInt(vista.getEmpleadotxtid().getText());

        // Realizar la búsqueda del empleado por su ID
        String empleadoEncontrado = bdEmpleado.buscarEmpleado(empleadoID);

        // Verificar si se encontró algún empleado
        if (!empleadoEncontrado.isEmpty()) {
            // Separar los valores del empleado encontrados por comas
            String[] valoresEmpleado = empleadoEncontrado.split(", ");

            // Llenar los campos de texto con los valores del empleado
            vista.getEmpleadotxtid().setText(valoresEmpleado[0]);
            vista.getEmpleadotxtnombre().setText(valoresEmpleado[1]);
            vista.getEmpleadotxtemail().setText(valoresEmpleado[2]);
            vista.getEmpleadotxtcc().setText(valoresEmpleado[3]);
            vista.getEmpleadotxtFCumpleaños().setText(valoresEmpleado[4]);
            vista.getEmpleadotxttelefono().setText(valoresEmpleado[5]);
            vista.getEmpleadotxtfecha().setText(valoresEmpleado[6]);
            vista.getEmpleadotxtSalario().setText(valoresEmpleado[7]);
             // Verificar el rol del empleado
            UsuariosDAO usuariosDAO = new UsuariosDAO();
            Usuarios usuarioActual = usuariosDAO.Login(Usuarios.getUsuario(), Usuarios.getClave());
             if (!usuarioActual.getRol().equals("administrador")) {
            vista.getEmpleadotxtcc().setEnabled(false);
        }
        } else {
            // No se encontró ningún empleado con el ID especificado, limpiar los campos
            limpiarCamposTexto();

            // Mostrar un mensaje indicando que no se encontró el empleado
            JOptionPane.showMessageDialog(vista, "No se encontró ningún empleado con el ID especificado.", "Búsqueda de Empleado", JOptionPane.INFORMATION_MESSAGE);
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(vista, "Ingrese un ID válido.", "Búsqueda de Empleado", JOptionPane.ERROR_MESSAGE);
    }
}

private void editarEmpleado() throws Exception {
    try {
        int empleadoID = Integer.parseInt(vista.getEmpleadotxtid().getText());
        UsuariosDAO usuariosDAO = new UsuariosDAO();
        Usuarios usuarioActual = usuariosDAO.Login(Usuarios.getUsuario(), Usuarios.getClave());
        vista.getEmpleadotxtcc().setEnabled(true);
        // Verificar si se ha ingresado un ID válido
        if (empleadoID > 0) {
            // Obtener los nuevos valores de los campos de texto
            String nombre = vista.getEmpleadotxtnombre().getText();
            String correo = vista.getEmpleadotxtemail().getText();
            String fechaNacimientoStr = vista.getEmpleadotxtFCumpleaños().getText();
            int telefono = Integer.parseInt(vista.getEmpleadotxttelefono().getText());
            String fechaIngresoStr = vista.getEmpleadotxtfecha().getText();
            double salario = Double.parseDouble(vista.getEmpleadotxtSalario().getText());
            int identificacion = Integer.parseInt(vista.getEmpleadotxtcc().getText());
            String estado = "activo";
            String usuario = vista.getTxtusuario().getText();
            String contraseña = new String(vista.getTxtcontraseña().getPassword());
            String rol = vista.getTxtrol().getText();
            Empleado empleado = new Empleado(empleadoID, nombre, correo, identificacion, fechaNacimientoStr, telefono, fechaIngresoStr, salario, estado,usuario, contraseña,rol);

            bdEmpleado.editarEmpleado(empleado);
            JOptionPane.showMessageDialog(vista, "Empleado editado correctamente.", "Editar Empleado", JOptionPane.INFORMATION_MESSAGE);
        } else {
            // Mostrar un mensaje de error si el ID es inválido
            JOptionPane.showMessageDialog(vista, "Ingrese un ID válido para editar el empleado.", "Editar Empleado", JOptionPane.ERROR_MESSAGE);
        }
        bdEmpleado.llenarTablaEmpleados(vista.getJtableEmpleados());
        /// vista.getEmpleadotxtcc().setEnabled(true);
          limpiarCamposTexto();
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(vista, "Ingrese valores numéricos válidos.", "Editar Empleado", JOptionPane.ERROR_MESSAGE);
    }
}

    void iniciar() {
        vista.setVisible(true);
    }

    private void eliminarEmpleado() {
    try {
        int empleadoID = Integer.parseInt(vista.getEmpleadotxtid().getText());

        // Verificar si se ha ingresado un ID válido
        if (empleadoID > 0) {
            // Confirmar la eliminación del empleado
            int confirmacion = JOptionPane.showConfirmDialog(vista, "¿Estás seguro de eliminar este empleado?", "Eliminar Empleado", JOptionPane.YES_NO_OPTION);
            if (confirmacion == JOptionPane.YES_OPTION) {
                // Realizar la eliminación del empleado en la base de datos
                bdEmpleado.eliminarEmpleado(empleadoID);

                // Mostrar un mensaje de éxito
                JOptionPane.showMessageDialog(vista, "Empleado eliminado correctamente.", "Eliminar Empleado", JOptionPane.INFORMATION_MESSAGE);

                // Limpiar los campos de texto
                limpiarCamposTexto();

                // Actualizar la tabla de empleados
                bdEmpleado.llenarTablaEmpleados(vista.getJtableEmpleados());
            }
        } else {
            // Mostrar un mensaje de error si el ID es inválido
            JOptionPane.showMessageDialog(vista, "Ingrese un ID válido para eliminar el empleado.", "Eliminar Empleado", JOptionPane.ERROR_MESSAGE);
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(vista, "Ingrese un ID válido.", "Eliminar Empleado", JOptionPane.ERROR_MESSAGE);
    }
}

   private void deshabilitarEmpleado() {
    try {
        int empleadoID = Integer.parseInt(vista.getEmpleadotxtid().getText());
        if (empleadoID > 0) {
            // Confirmar la deshabilitación del empleado
            int confirmacion = JOptionPane.showConfirmDialog(vista, "¿Estás seguro de deshabilitar este empleado?", "Deshabilitar Empleado", JOptionPane.YES_NO_OPTION);
            if (confirmacion == JOptionPane.YES_OPTION) {
                bdEmpleado.deshabilitarE(empleadoID);
                JOptionPane.showMessageDialog(vista, "Empleado deshabilitado correctamente.", "Deshabilitar Empleado", JOptionPane.INFORMATION_MESSAGE);
                bdEmpleado.llenarTablaEmpleados(vista.getJtableEmpleados());
            }
        } else {
            // Mostrar un mensaje de error si el ID es inválido
            JOptionPane.showMessageDialog(vista, "Ingrese un ID válido para deshabilitar el empleado.", "Deshabilitar Empleado", JOptionPane.ERROR_MESSAGE);
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(vista, "Ingrese un ID válido.", "Deshabilitar Empleado", JOptionPane.ERROR_MESSAGE);
    }
}
   
   private void habilitarEmpleado() {
    try {
        int empleadoID = Integer.parseInt(vista.getEmpleadotxtid().getText());
        if (empleadoID > 0) {
            // Confirmar la habilitación del empleado
            int confirmacion = JOptionPane.showConfirmDialog(vista, "¿Estás seguro de habilitar este empleado?", "habilitar Empleado", JOptionPane.YES_NO_OPTION);
            if (confirmacion == JOptionPane.YES_OPTION) {
                bdEmpleado.habilitarE(empleadoID);
                JOptionPane.showMessageDialog(vista, "Empleado habilitado correctamente.", "habilitar Empleado", JOptionPane.INFORMATION_MESSAGE);
                bdEmpleado.llenarTablaEmpleados(vista.getJtableEmpleados());
            }
        } else {
            // Mostrar un mensaje de error si el ID es inválido
            JOptionPane.showMessageDialog(vista, "Ingrese un ID válido para deshabilitar el empleado.", "habilitar Empleado", JOptionPane.ERROR_MESSAGE);
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(vista, "Ingrese un ID válido.", "habilitar Empleado", JOptionPane.ERROR_MESSAGE);
    }
}
private void calcularBonoCumpleaños() {
    try {
        int empleadoID = Integer.parseInt(vista.getEmpleadotxtid().getText());

        if (empleadoID > 0) {
            double bono = bdEmpleado.calcularBonoCumpleaños(empleadoID);

            if (bono > 0) {
                // Felicitar al empleado y mostrar el bono
                JOptionPane.showMessageDialog(vista, "este empleado tiene un bono del 10% sobre su salario. Bono: $" + bono, "Bono de Cumpleaños", JOptionPane.INFORMATION_MESSAGE);

                // Agregar el valor del bono al campo de texto txtcumpleaños
                vista.getTxtcumpleaños().setText("$" + bono);
            } else {
                // Mostrar un mensaje indicando que no hay bono
                JOptionPane.showMessageDialog(vista, "Hoy no es tu cumpleaños. No tienes bono.", "Bono de Cumpleaños", JOptionPane.INFORMATION_MESSAGE);

                // Actualizar el campo de texto txtcumpleaños con el resultado
                vista.getTxtcumpleaños().setText("No tiene Bono de Cumpleaños");
            }
        } else {
            // Mostrar un mensaje de error si el ID es inválido
            JOptionPane.showMessageDialog(vista, "Ingrese un ID válido para calcular el bono de cumpleaños.", "Bono de Cumpleaños", JOptionPane.ERROR_MESSAGE);
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(vista, "Ingrese un ID válido.", "Bono de Cumpleaños", JOptionPane.ERROR_MESSAGE);
    }
}

    private void limpiarCamposTexto() {
        vista.getEmpleadotxtid().setText("");
        vista.getEmpleadotxtnombre().setText("");
        vista.getEmpleadotxtemail().setText("");
        vista.getEmpleadotxtcc().setText("");
        vista.getEmpleadotxtFCumpleaños().setText("");
        vista.getEmpleadotxttelefono().setText("");
        vista.getEmpleadotxtfecha().setText("");
        vista.getEmpleadotxtSalario().setText("");
        vista.getTxtrol().setText("");
        vista.getTxtusuario().setText("");
        vista.getTxtcontraseña().setText("");
    }

}
