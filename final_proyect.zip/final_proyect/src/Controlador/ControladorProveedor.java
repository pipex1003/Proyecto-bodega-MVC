/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.ProveedorDAO;
import Modelo.Proveedor;
import Modelo.Usuarios;
import Modelo.UsuariosDAO;
import Vista.FormularioProveedores;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ControladorProveedor implements ActionListener {
    
    private FormularioProveedores vista;
    private ProveedorDAO bdProveedor;
    private DefaultTableModel modelo;
    
    public ControladorProveedor() {
        vista = new FormularioProveedores();
        this.vista.setLocationRelativeTo(null);
        bdProveedor = new ProveedorDAO();
        vista.getBtneliminarproveedores().addActionListener(this);
        vista.getBtnmodificarproveedores().addActionListener(this);
        vista.getBtnguardarproveedores().addActionListener(this);
        vista.getBtnbuscarproveedores().addActionListener(this);
        vista.getBtnComi().addActionListener(this);
        modelo = (DefaultTableModel) vista.getJTableProveedores().getModel();
        bdProveedor.llenarTablaProveedor(vista.getJTableProveedores());
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.getBtnguardarproveedores()) {
            agregarProveedor();
        } else if (e.getSource() == vista.getBtnmodificarproveedores()) {
            try {
                modificarProveedor();
            } catch (Exception ex) {
                Logger.getLogger(ControladorProveedor.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (e.getSource() == vista.getBtneliminarproveedores()) {
            eliminarProveedor();
        }else if(e.getSource()== vista.getBtnbuscarproveedores()){
            buscarProveedor();
        } else if (e.getSource() == vista.getBtnComi()) {
        try {
            int empleadoID = Integer.parseInt(vista.getIDcomi().getText());
            int comision = bdProveedor.calcularComision(empleadoID);
            JOptionPane.showMessageDialog(vista, "La comisión del empleado es: $" + comision, "Calcular Comisión", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, "Ingrese un ID válido.", "Calcular Comisión", JOptionPane.ERROR_MESSAGE);
        }
    }
    }
    
    private void agregarProveedor() {
        int ProveedorID = Integer.parseInt(vista.getTxtidproveedor().getText());
        String Nombre = vista.getTxtnombreproveedor().getText();
        int Telefono = Integer.parseInt(vista.getTxttelefonoproveedor().getText());
        String Direccion = vista.getTxtdireccionproveedor().getText();
        Proveedor proveedores = new Proveedor(ProveedorID, Nombre, Telefono, Direccion);
        bdProveedor.ingresarProveedor(proveedores);
        limpiarCamposTexto();
        bdProveedor.llenarTablaProveedor(vista.getJTableProveedores());
        JOptionPane.showMessageDialog(vista, "Proveedor agregado correctamente.");
    }
  private void buscarProveedor() {
    int proveedorID = Integer.parseInt(vista.getTxtidproveedor().getText());

    // Realizar la búsqueda del proveedor por su ID
    String proveedorEncontrado = bdProveedor.buscarProveedor(proveedorID);

    // Verificar si se encontró algún proveedor
    if (!proveedorEncontrado.isEmpty()) {
        // Separar los valores del proveedor encontrados por comas
        String[] valoresProveedor = proveedorEncontrado.split(", ");

        // Llenar los campos de texto con los valores del proveedor
        vista.getTxtidproveedor().setText(valoresProveedor[0]);
        vista.getTxtnombreproveedor().setText(valoresProveedor[1]);
        vista.getTxttelefonoproveedor().setText(valoresProveedor[2]);
        vista.getTxtdireccionproveedor().setText(valoresProveedor[3]);

        // Verificar el rol del empleado
        UsuariosDAO usuariosDAO = new UsuariosDAO();
        Usuarios usuarioActual = usuariosDAO.Login(Usuarios.getUsuario(), Usuarios.getClave());

        // Si el rol del empleado no es administrador, deshabilitar el campo proveedorID
        if (!usuarioActual.getRol().equals("administrador")) {
            vista.getTxtidproveedor().setEnabled(false);
        }
    } else {
        // No se encontró ningún proveedor con el ID especificado, limpiar los campos
        vista.getTxtidproveedor().setText("");
        vista.getTxtnombreproveedor().setText("");
        vista.getTxttelefonoproveedor().setText("");
        vista.getTxtdireccionproveedor().setText("");

        // Mostrar un mensaje indicando que no se encontró el proveedor
        JOptionPane.showMessageDialog(vista, "No se encontró ningún proveedor con el ID especificado.", "Búsqueda de Proveedor", JOptionPane.INFORMATION_MESSAGE);
    }
}

    private void modificarProveedor() throws Exception {
        // Obtener los valores de los campos de texto
        int ProveedorID = Integer.parseInt(vista.getTxtidproveedor().getText());
        String Nombre = vista.getTxtnombreproveedor().getText();
        int Telefono = Integer.parseInt(vista.getTxttelefonoproveedor().getText());
        String Direccion = vista.getTxtdireccionproveedor().getText();

        // Crear el objeto Proveedor con los datos ingresados
        Proveedor proveedores = new Proveedor(ProveedorID, Nombre, Telefono, Direccion);

        // Modificar el proveedor en la base de datos
        bdProveedor.modificarProveedor(proveedores);

        // Limpiar los campos de texto
        limpiarCamposTexto();

        // Actualizar la tabla de proveedores con el nuevo proveedor agregado
        bdProveedor.llenarTablaProveedor(vista.getJTableProveedores());

        // Mostrar un mensaje de éxito
        JOptionPane.showMessageDialog(vista, "Proveedor modificado correctamente.");
        vista.getTxtidproveedor().setEnabled(true);
    }
    
    private void eliminarProveedor() {
        // Obtener el ID del proveedor seleccionado en la tabla
        int idProveedor = Integer.parseInt(vista.getTxtidproveedor().getText());

        // Eliminar el proveedor de la base de datos
        bdProveedor.borrarproveedor(idProveedor);

        // Limpiar los campos de texto
        limpiarCamposTexto();

        // Actualizar la tabla de proveedores con el nuevo proveedor agregado
        bdProveedor.llenarTablaProveedor(vista.getJTableProveedores());

        // Mostrar un mensaje de éxito
        //JOptionPane.showMessageDialog(vista, "Proveedor eliminado correctamente.");
    }
    
    private void limpiarCamposTexto() {
        vista.getTxtidproveedor().setText("");
        vista.getTxtnombreproveedor().setText("");
        vista.getTxttelefonoproveedor().setText("");
        vista.getTxtdireccionproveedor().setText("");
    }
    
    public void iniciar() {
        vista.setVisible(true);
    }
    
}

