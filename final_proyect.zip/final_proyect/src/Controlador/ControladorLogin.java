package Controlador;

import Modelo.Usuarios;
import Modelo.UsuariosDAO;
import Vista.FormularioLogin;
import Vista.paneladmin;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 *
 * @author ANDRES AVILA
 */
public class ControladorLogin implements ActionListener {
    private Usuarios us;
    private UsuariosDAO usdao;
    private FormularioLogin fmrl;

    public ControladorLogin(Usuarios us, UsuariosDAO usdao, FormularioLogin fmrl) {
        this.us = us;
        this.usdao = usdao;
        this.fmrl = fmrl;
        this.fmrl.btnlogin.addActionListener(this);
        this.fmrl.btnsalir.addActionListener(this);
        this.fmrl.setLocationRelativeTo(null);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == fmrl.btnlogin) {
            if (fmrl.txtusuario.getText().equals("") || String.valueOf(fmrl.txtclave.getPassword()).equals("")) {
                JOptionPane.showMessageDialog(null, "Campos vacíos");
            } else {
                String usuario = fmrl.txtusuario.getText();
                String clave = String.valueOf(fmrl.txtclave.getPassword());

                us = usdao.Login(usuario, clave);
                if (us.getUsuario() != null) {
                    if (us.getEstado().equals("activo")) {
                        paneladmin admin = new paneladmin();
                        admin.setVisible(true);
                        this.fmrl.dispose();
                    } else {
                        JOptionPane.showMessageDialog(null, "Usuario inactivo. No se permite el acceso.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos");
                }
            }
        } else {
            int pregunta = JOptionPane.showConfirmDialog(null, "¿Está seguro de salir?", "Pregunta", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (pregunta == 0) {
                System.exit(0);
            }
        }
    }
}
