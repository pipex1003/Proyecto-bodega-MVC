/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.CompraDAO;
import Modelo.Compra;
import Vista.FormularioCompras;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ANDRES AVILA
 */
public class ControladorCompras implements ActionListener {

   private FormularioCompras vista;
   private CompraDAO bdEmpleado;
   private DefaultTableModel modelo;

   public ControladorCompras() {
       vista = new FormularioCompras();
       bdEmpleado = new CompraDAO();
       vista.setVisible(true);
       // Configurar el ActionListener para los botones
       vista.getBtnguardarcompra().addActionListener(this);
       vista.getBtnmodificarcompra().addActionListener(this);
       vista.getBtneliminarcompra().addActionListener(this);
       vista.getBtnbuscar().addActionListener(this);
       // Obtener el modelo de la tabla
       modelo = (DefaultTableModel) vista.getTablaCompras().getModel();

       // Llenar la tabla con los datos de la base de datos
       bdEmpleado.llenarTablaCompras(vista.getTablaCompras());
       this.vista.setLocationRelativeTo(null);
   }

   @Override
   public void actionPerformed(ActionEvent e) {
       if (e.getSource() == vista.getBtnguardarcompra()) {
           try {
               guardarCompra();
           } catch (ParseException ex) {
               Logger.getLogger(ControladorCompras.class.getName()).log(Level.SEVERE, null, ex);
           }
       } else if (e.getSource() == vista.getBtnmodificarcompra()) {
           try {
               modificarCompra();
           } catch (ParseException ex) {
               Logger.getLogger(ControladorCompras.class.getName()).log(Level.SEVERE, null, ex);
           }
       } else if (e.getSource() == vista.getBtneliminarcompra()) {
           borrarCompra();
       }else if (e.getSource() == vista.getBtnbuscar()) {
           buscarArticulo();
       }
   }

   private void guardarCompra() throws ParseException {
       Compra compra = new Compra();
       //Trae los datos de la vista
       int numeroDeFactura = Integer.parseInt(vista.getTxtnumfacturacompra().getText());
       int cantidad = Integer.parseInt(vista.getTxtcantidadcompra().getText());
       double valorDeCompra = Double.parseDouble(vista.getTxtvalorcompra().getText());
       double impuesto = Double.parseDouble(vista.getTxtimpuestocompra().getText());
       double totalPagar = Double.parseDouble(vista.getTxtvtotalcompra().getText());
       int serializado=Integer.parseInt(vista.getTxtseriecompra().getText());
       int proveedorID = Integer.parseInt(vista.getTxtidproveedorcompra().getText());
       String  fechaDeCompra = vista.getTxtfechacompra().getText();

       //setea los datos
       compra.setNumeroDeFactura(numeroDeFactura);
       compra.setCantidad(cantidad);
       compra.setValorDeCompra(valorDeCompra);
       compra.setImpuesto(impuesto);
       compra.setTotalPagar(totalPagar);
       compra.setProveedorID(proveedorID);
       compra.setSerializado(serializado);
       compra.setFechaDeCompra(fechaDeCompra);
       bdEmpleado.ingresarCompra(compra);
       modelo.addRow(new Object[]{compra.getNumeroDeFactura(), compra.getCantidad(), compra.getValorDeCompra(), compra.getImpuesto(), compra.getTotalPagar(), compra.getProveedorID(),compra.getSerializado() ,compra.getFechaDeCompra()});
       bdEmpleado.llenarTablaCompras(vista.getTablaCompras());
       limpiarCamposTexto();
       JOptionPane.showMessageDialog(vista, "compra guardada correctamente.", "guardar compra", JOptionPane.INFORMATION_MESSAGE);
   }

   private void modificarCompra() throws ParseException {
//Traer el id, se modifica por id.
       Compra compra = new Compra();
       int numeroDeFactura = Integer.parseInt(vista.getTxtnumfacturacompra().getText());
//Traer los demas datos
       int cantidad = Integer.parseInt(vista.getTxtcantidadcompra().getText());
       double valorDeCompra = Double.parseDouble(vista.getTxtvalorcompra().getText());
       double impuesto = Double.parseDouble(vista.getTxtimpuestocompra().getText());
       double totalPagar = Double.parseDouble(vista.getTxtvtotalcompra().getText());
       int proveedorID = Integer.parseInt(vista.getTxtidproveedorcompra().getText());
       String  fechaDeCompra = vista.getTxtfechacompra().getText();
//Instancia a compra y setea los datos.
       compra.setNumeroDeFactura(numeroDeFactura);
       compra.setCantidad(cantidad);
       compra.setValorDeCompra(valorDeCompra);
       compra.setImpuesto(impuesto);
       compra.setTotalPagar(totalPagar);
       compra.setProveedorID(proveedorID);
       compra.setFechaDeCompra(fechaDeCompra);
//Envio los datos a la base de datos.
       bdEmpleado.modificarCompra(compra);
//Actualizar Vista
       bdEmpleado.llenarTablaCompras(vista.getTablaCompras());
       limpiarCamposTexto();
       JOptionPane.showMessageDialog(vista, "compra modificada correctamente.", "modificar compra", JOptionPane.INFORMATION_MESSAGE);
   }

   private void borrarCompra() {
       int numeroDeFactura = Integer.parseInt(vista.getTxtnumfacturacompra().getText());
       bdEmpleado.borrarCompra(numeroDeFactura);
       bdEmpleado.llenarTablaCompras(vista.getTablaCompras());
       limpiarCamposTexto();
       JOptionPane.showMessageDialog(vista, "compra eliminada correctamente.", "Eliminar compra", JOptionPane.INFORMATION_MESSAGE);
   }
  private void limpiarCamposTexto() {
   vista.getTxtnumfacturacompra().setText("");
   vista.getTxtcantidadcompra().setText("");
   vista.getTxtvalorcompra().setText("");
   vista.getTxtimpuestocompra().setText("");
   vista.getTxtvtotalcompra().setText("");
   vista.getTxtidproveedorcompra().setText("");
   vista.getTxtseriecompra().setText("");
   vista.getTxtfechacompra().setText("");
}
 private void buscarArticulo() {
       try {
           int serializado = Integer.parseInt(vista.getTxtnumfacturacompra().getText());

           // Realizar la búsqueda del artículo por su Serializado
           String articuloEncontrado = bdEmpleado.buscarCompra(serializado);

           // Verificar si se encontró algún artículo
           if (!articuloEncontrado.isEmpty()) {
               // Separar los valores del artículo encontrados por comas
               String[] valoresArticulo = articuloEncontrado.split(", ");

               // Llenar los campos de texto con los valores del artículo
               vista.getTxtnumfacturacompra().setText(valoresArticulo[0]);
               vista.getTxtcantidadcompra().setText(valoresArticulo[1]);
               vista.getTxtvalorcompra().setText(valoresArticulo[2]);
               vista.getTxtimpuestocompra().setText(valoresArticulo[3]);
               vista.getTxtvtotalcompra().setText(valoresArticulo[4]);
               vista.getTxtidproveedorcompra().setText(valoresArticulo[5]);
               vista.getTxtseriecompra().setText(valoresArticulo[6]);
               vista.getTxtfechacompra().setText(valoresArticulo[7]);

               // Additional fields can be filled here based on your data model
           } else {
               // No se encontró ningún artículo con el Serializado especificado, limpiar los campos
               limpiarCamposTexto();

               // Mostrar un mensaje indicando que no se encontró el artículo
               JOptionPane.showMessageDialog(vista, "No se encontró ningún artículo con el Serializado especificado.", "Búsqueda de Artículo", JOptionPane.INFORMATION_MESSAGE);
           }
       } catch (NumberFormatException e) {
           JOptionPane.showMessageDialog(vista, "Ingrese un Serializado válido.", "Búsqueda de Artículo", JOptionPane.ERROR_MESSAGE);
       }
   }
}

