package Controlador;

import Modelo.EmpleadoArticulo;
import Modelo.EmpleadoArticuloDAO;
import Vista.EmpleadoDevolucion;
import Vista.FormularioEmpleadoArticulo;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ControladorEmpleadoArticulo implements ActionListener {

    private FormularioEmpleadoArticulo vista;
    private EmpleadoArticuloDAO bdEmpleadoArticulo;
    private DefaultTableModel modelo;
    private EmpleadoDevolucion vistaDevolucion;
    public ControladorEmpleadoArticulo() {
        vista = new FormularioEmpleadoArticulo();
        vistaDevolucion = new EmpleadoDevolucion();
        bdEmpleadoArticulo = new EmpleadoArticuloDAO();
        vista.setVisible(true);
        this.vista.setLocationRelativeTo(null);
        
        // Configurar el ActionListener para los botones
        vista.getBtnAsiganarCentroC().addActionListener(this);
        vista.getBtnModificarCentroCAsignar().addActionListener(this);
        vista.getBtnEliminarCentroCAsignar().addActionListener(this);
        vista.getBtnDevoluciones().addActionListener(this);
        // Obtener el modelo de la tabla
        modelo = (DefaultTableModel) vista.getTablaDatos().getModel();
        
        // Llenar la tabla con los datos de la base de datos
        bdEmpleadoArticulo.llenarTablaEmpleadoArticulos(vista.getTablaDatos());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.getBtnAsiganarCentroC()) {
            asignarArticulo();
        } else if (e.getSource() == vista.getBtnModificarCentroCAsignar()) {
            modificarArticulo();
        } else if (e.getSource() == vista.getBtnEliminarCentroCAsignar()) {
            eliminarArticulo();
        }else if (e.getSource() == vista.getBtnDevoluciones()) {
          llenarTablaDevoluciones();}
    }
 private void llenarTablaDevoluciones() {
     vistaDevolucion.setVisible(true);
      vistaDevolucion.setLocationRelativeTo(null);
      bdEmpleadoArticulo.llenarTablaEmpleadoArticuloDevolucion(vistaDevolucion.getTablaDatos1());
      
  }
   private void asignarArticulo() {
   try {
       // Obtén los valores de los campos
       String txtArticuloID = vista.getTxtArticuloID().getText().trim();
       String txtempleadoID = vista.getTxtempleadoID().getText().trim();

       // Verifica que los campos no estén vacíos
       if (txtArticuloID.isEmpty() || txtempleadoID.isEmpty()) {
           JOptionPane.showMessageDialog(null, "Ingrese valores para Empleado ID y Artículo ID", "Error", JOptionPane.ERROR_MESSAGE);
           return;
       }

       // Convierte las cadenas a números
       Integer articuloID = Integer.valueOf(txtArticuloID);
       Integer empleadoid = Integer.valueOf(txtempleadoID);

       // Obtiene la fecha actual
       String fecha_entrega = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

       // Asegúrate de que los parámetros se pasen en el orden correcto
       EmpleadoArticulo empleadoArticulo = new EmpleadoArticulo(articuloID, empleadoid, fecha_entrega);

       // Guarda el empleado en la BD
       bdEmpleadoArticulo.guardarEmpleadoArticulo(empleadoArticulo, fecha_entrega);

       // Se limpian los campos de texto
       limpiarCampos();
       // Se refresca la tabla
       bdEmpleadoArticulo.llenarTablaEmpleadoArticulos(vista.getTablaDatos());
   } catch (NumberFormatException ex) {
       JOptionPane.showMessageDialog(null, "Ingrese valores numéricos válidos para Empleado ID y Artículo ID", "Error", JOptionPane.ERROR_MESSAGE);
   }
}






    private void modificarArticulo() {
        try {
            int articuloid = Integer.parseInt(vista.getTxtArticuloID().getText());
            int empleadoid = Integer.parseInt(vista.getTxtempleadoID().getText());
            String fechaEntrega = vista.getTxtfechaentrega().getText();

            EmpleadoArticulo empleadoArticulo = new EmpleadoArticulo(articuloid, empleadoid, fechaEntrega);
            bdEmpleadoArticulo.modificarEmpleadoArticulo(empleadoArticulo); // Método que modifica el empleado en la BD

            // Se limpian los campos de texto
            limpiarCampos();
            // Se refresca la tabla
            bdEmpleadoArticulo.llenarTablaEmpleadoArticulos(vista.getTablaDatos());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Ingrese valores numéricos para Empleado ID y Artículo ID", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarArticulo() {
        try {
            int empleadoid = Integer.parseInt(vista.getTxtempleadoID().getText());
            int articuloID = Integer.parseInt(vista.getTxtArticuloID().getText());

            bdEmpleadoArticulo.eliminarEmpleadoArticulo(articuloID, empleadoid); // Método que elimina el empleado en la BD

            // Se limpian los campos de texto
            limpiarCampos();
            // Se refresca la tabla
            bdEmpleadoArticulo.llenarTablaEmpleadoArticulos(vista.getTablaDatos());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Ingrese valores numéricos para Empleado ID y Artículo ID", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limpiarCampos() {
        vista.getTxtempleadoID().setText("");
        vista.getTxtArticuloID().setText("");
        vista.getTxtfechaentrega().setText("");
    }

    public void iniciar() {
        vista.setVisible(true);
    }
}
