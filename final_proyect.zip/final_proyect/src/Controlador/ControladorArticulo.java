/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Articulo;
import Modelo.ArticuloDAO;
import Vista.FormularioArticulos;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ANDRES AVILA
 */
public class ControladorArticulo  implements ActionListener {

    private FormularioArticulos vista;
    private ArticuloDAO bdArticulo;
    private DefaultTableModel modelo;
    private Articulo articulo;

       public ControladorArticulo() {
        vista = new FormularioArticulos();
        bdArticulo = new ArticuloDAO();
        vista.setVisible(true);
        vista.getBtneliminararticulos().addActionListener(this);
        vista.getBtnguardararticulos().addActionListener(this);
        vista.getBtnmodificararticulos().addActionListener(this);
        vista.getBtnbuscar().addActionListener(this);
        modelo = (DefaultTableModel) vista.getTablaarticulos().getModel();
        bdArticulo.llenarTablaArticulos(vista.getTablaarticulos());
        this.vista.setLocationRelativeTo(null);
    }
   
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.getBtnguardararticulos()) {
            System.out.println("Guardando articulo");
            guardarArticulo();
        } else if (e.getSource() == vista.getBtnmodificararticulos()) {
             System.out.println("Modificando articulo");
            modificarArticulo();
        } else if (e.getSource() == vista.getBtneliminararticulos()) {
            System.out.println("Eliminando articulo");
            eliminarArticulo();
        }else if (e.getSource() == vista.getBtnbuscar()) {
        System.out.println("Buscando articulo");
        buscarArticulo();
    }
    }
   
    private void guardarArticulo() {
        //Traer los datos de la vista
        int serializado = Integer.parseInt(vista.getTxtidarticulos().getText());
        String descripcion = vista.getTxtdescripcionarticulo().getText();
        double impuesto = Double.parseDouble(vista.getTxtporcImpuestosarticulo().getText());
        String nombre = vista.getTxtnombre().getText();
        //String tipo = vista.getTxtseriearticulo().getText();
        //String familia = vista.getTxtfamiliaarticulo().getText();
        String categoria = vista.getTxtcategoriaarticulo().getText();
        int vidaUtil = Integer.parseInt(vista.getTxtvidautilarticulo().getText());

        articulo = new Articulo(serializado, descripcion, impuesto, nombre, categoria, vidaUtil);

        bdArticulo.ingresarArticulo(articulo);
        limpiarCampos();

        bdArticulo.llenarTablaArticulos(vista.getTablaarticulos());
    }
   
    private void modificarArticulo() {
        //Traer el id a modificar
        int idSeleccionado = Integer.parseInt(vista.getTxtidarticulos().getText());

        //Traer los datos de la vista
        int serializado = Integer.parseInt(vista.getTxtidarticulos().getText());
        String descripcion = vista.getTxtdescripcionarticulo().getText();
        double impuesto = Double.parseDouble(vista.getTxtporcImpuestosarticulo().getText());
        String nombre = vista.getTxtnombre().getText();
       // String tipo = vista.getTxtseriearticulo().getText();
        //String familia = vista.getTxtfamiliaarticulo().getText();
        String categoria = vista.getTxtcategoriaarticulo().getText();
        int vidaUtil = Integer.parseInt(vista.getTxtvidautilarticulo().getText());

        articulo = new Articulo(serializado, descripcion, impuesto, nombre, categoria, vidaUtil);
        bdArticulo.modificarArticulo(articulo);
        limpiarCampos();

        // Llenar la tabla con los datos de la base de datos
        bdArticulo.llenarTablaArticulos(vista.getTablaarticulos());
    }
   
    private void eliminarArticulo() {
        //Traer el id a eliminar
        int idSeleccionado = Integer.parseInt(vista.getTxtidarticulos().getText());
        bdArticulo.borrarArticulo(idSeleccionado);
        limpiarCampos();

        // Llenar la tabla con los datos de la base de datos
        bdArticulo.llenarTablaArticulos(vista.getTablaarticulos());
    }
   
    private void limpiarCampos() {
        vista.getTxtidarticulos().setText(null);
        vista.getTxtdescripcionarticulo().setText(null);
        vista.getTxtporcImpuestosarticulo().setText(null);
        vista.getTxtnombre().setText(null);
       // vista.getTxtseriearticulo().setText(null);
       // vista.getTxtfamiliaarticulo().setText(null);
        vista.getTxtcategoriaarticulo().setText(null);
        vista.getTxtvidautilarticulo().setText(null);
    }
  
public void iniciar() {
        vista.setVisible(true);
    }
private void buscarArticulo() {
    try {
        int serializado = Integer.parseInt(vista.getTxtidarticulos().getText());

        // Realizar la búsqueda del artículo por su Serializado
        String articuloEncontrado = bdArticulo.buscarArticulo(serializado);

        // Verificar si se encontró algún artículo
        if (!articuloEncontrado.isEmpty()) {
            // Separar los valores del artículo encontrados por comas
            String[] valoresArticulo = articuloEncontrado.split(", ");

            // Llenar los campos de texto con los valores del artículo
            vista.getTxtidarticulos().setText(valoresArticulo[0]);
            vista.getTxtdescripcionarticulo().setText(valoresArticulo[1]);
            vista.getTxtporcImpuestosarticulo().setText(valoresArticulo[2]);
            vista.getTxtnombre().setText(valoresArticulo[3]);
            vista.getTxtcategoriaarticulo().setText(valoresArticulo[4]);
            vista.getTxtvidautilarticulo().setText(valoresArticulo[5]);

            // Additional fields can be filled here based on your data model
        } else {
            // No se encontró ningún artículo con el Serializado especificado, limpiar los campos
            limpiarCampos();

            // Mostrar un mensaje indicando que no se encontró el artículo
            JOptionPane.showMessageDialog(vista, "No se encontró ningún artículo con el Serializado especificado.", "Búsqueda de Artículo", JOptionPane.INFORMATION_MESSAGE);
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(vista, "Ingrese un Serializado válido.", "Búsqueda de Artículo", JOptionPane.ERROR_MESSAGE);
    }
}


} 


