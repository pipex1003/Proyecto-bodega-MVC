/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

/**
 *
 * @author ANDRES AVILA
 */

import Modelo.EmpleadoDAO;
import Modelo.EmpleadoCentroDAO;
import Modelo.EmpleadoCentro;
import Vista.FormularioEmpleadoCentro;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ControladorEmpleadoCentro  implements ActionListener {

 private FormularioEmpleadoCentro vista;
 private EmpleadoCentroDAO bdEmpleadoCentroCosto;
 private EmpleadoDAO bdEmpleado;
 private DefaultTableModel modelo;

 public ControladorEmpleadoCentro() {
     vista = new FormularioEmpleadoCentro();
     bdEmpleadoCentroCosto = new EmpleadoCentroDAO();
     bdEmpleado = new EmpleadoDAO();
//     vista.setVisible(true);
     vista.setVisible(true);
     this.vista.setLocationRelativeTo(null);
     // Configurar el ActionListener para los botones
     vista.getBtnAsiganarCentroC().addActionListener(this);
     vista.getBtnModificarCentroCAsignar().addActionListener(this);
     vista.getBtnEliminarCentroCAsignar().addActionListener(this);
     
     // Obtener el modelo de la tabla
     modelo = (DefaultTableModel) vista.getTablaDatos().getModel();

     // Llenar la tabla con los datos de la base de datos
     bdEmpleadoCentroCosto.llenarTablaEmpleadoCentroCostos(vista.getTablaDatos());
 }

 @Override
 public void actionPerformed(ActionEvent e) {
     if (e.getSource() == vista.getBtnAsiganarCentroC()) {
         asignarCentroCosto();
        
     } else if (e.getSource() == vista.getBtnModificarCentroCAsignar()) {
         modificarCentroCosto();
     } else if (e.getSource() == vista.getBtnEliminarCentroCAsignar()) {
         eliminarCentroCosto();
     }
 }

 private void asignarCentroCosto() {
     int empleadoID = Integer.parseInt(vista.getTxtempleadoID().getText());
     int centroDeCostoID = Integer.parseInt(vista.getTxtcentroID().getText());

     EmpleadoCentro empleadoCentroDeCosto = new EmpleadoCentro(empleadoID, centroDeCostoID);
     bdEmpleadoCentroCosto.guardarEmpleadoCentroDeCosto(empleadoCentroDeCosto); //Método que guarda el empleado en la BD

     //Se limpian los campos de texto
     limpiarCampos();
     //Se refresca la tabla
     bdEmpleadoCentroCosto.llenarTablaEmpleadoCentroCostos(vista.getTablaDatos());
 }

 //Método que modifica valores en la base de datos
 private void modificarCentroCosto() {
     int empleadoID = Integer.parseInt(vista.getTxtempleadoID().getText());
     int centroDeCostoID = Integer.parseInt(vista.getTxtcentroID().getText());

     EmpleadoCentro empleadoCentroDeCosto = new EmpleadoCentro(empleadoID, centroDeCostoID);
     bdEmpleadoCentroCosto.modificarEmpleadoCentroDeCosto(empleadoCentroDeCosto); //Método que modifica el empleado en la BD

     //Se limpian los campos de texto
     limpiarCampos();
     //Se refresca la tabla
     bdEmpleadoCentroCosto.llenarTablaEmpleadoCentroCostos(vista.getTablaDatos());
 }

 //Método que elimina valores en la base de datos
 private void eliminarCentroCosto() {
     int empleadoID = Integer.parseInt(vista.getTxtempleadoID().getText());
     int centroDeCostoID = Integer.parseInt(vista.getTxtcentroID().getText());

     EmpleadoCentro empleadoCentroDeCosto = new EmpleadoCentro(empleadoID, centroDeCostoID);
     bdEmpleadoCentroCosto.eliminarEmpleadoCentroDeCosto(empleadoID, centroDeCostoID); //Método que elimina el empleado en la BD

     //Se limpian los campos de texto
     limpiarCampos();
     //Se refresca la tabla
     bdEmpleadoCentroCosto.llenarTablaEmpleadoCentroCostos(vista.getTablaDatos());
 }

 //Método que limpia los campos de texto
 private void limpiarCampos() {
     vista.getTxtempleadoID().setText("");
     vista.getTxtcentroID().setText("");
 }
   public void iniciar() {
        vista.setVisible(true);
    }
    
}


